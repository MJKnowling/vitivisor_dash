#Created 1/04/2020

read.daily.weather<-function(Date=NULL,Weatherfile=NULL){
  index<-which(Weatherfile$Date==Date)
  output<-list()
  output$Tmax<-Weatherfile$TMAX[index]
  output$Tmin<-Weatherfile$TMIN[index]
  output$Tmean<-(output$Tmax+output$Tmin)/2
  return(output)

}
