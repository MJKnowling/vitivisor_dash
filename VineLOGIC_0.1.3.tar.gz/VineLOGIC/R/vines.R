# Created 2/03/2020 by Sam Culley
#
# Main script for daily timestep simulation of VineLOGIC


vines<-function(start_date="1999-01-01",input_file_dir=NULL,sim_length=40,da_cycle=NULL,real_idx=NULL){
  ######################################
  ### Temporarily load for debugging ###
  ######################################
  # library(jsonlite)
  # source("C:/Users/Sam/Desktop/GitProjects/VineLOGIC/R/GrowthStages.R")
  # source("C:/Users/Sam/Desktop/GitProjects/VineLOGIC/R/IrrigationFunctions.R")
  # source("C:/Users/Sam/Desktop/GitProjects/VineLOGIC/R/WeatherFunctions.R")
  # dyn.load("C:/Users/Sam/Desktop/GitProjects/VineLOGIC/src/shared3.so")
  # start_date="1999-01-01"
  # sim_length=900
  # input_file_dir="C:/Users/Sam/Desktop/GitProjects/VineLOGIC/inst/extdata/"
  # Control<-fromJSON(file.path("C:/Users/Sam/Desktop/GitProjects/VineLOGIC/inst/parameters","control.json",fsep = .Platform$file.sep))

  ############################
  ### Read all .json files ###
  ############################

  #MJK: TODO: add default variable functionality so that can switch between defaults for variety (e.g., shiraz), soil (e.g., loam), rootstock (e.g., Schwarzmann). Was intened given addition of key words/key codes.

  if(!is.null(input_file_dir)){
    BerryCultivar<-fromJSON(file.path(input_file_dir,"BerryCultivar.json",fsep = .Platform$file.sep))
    Cultivar<-fromJSON(file.path(input_file_dir,"Cultivar.json",fsep = .Platform$file.sep))
    HarvestControl<-fromJSON(file.path(input_file_dir,"HarvestControl.json",fsep = .Platform$file.sep))
    HydrologyParameters<-fromJSON(file.path(input_file_dir,"HydrologyParameters.json",fsep = .Platform$file.sep))
    InitialSoilConditions<-fromJSON(file.path(input_file_dir,"InitialSoilConditions.json",fsep = .Platform$file.sep))
    ObservedIrrigation<-fromJSON(file.path(input_file_dir,"ObservedIrrigation.json",fsep = .Platform$file.sep))
    Rootstock<-fromJSON(file.path(input_file_dir,"Rootstock.json",fsep = .Platform$file.sep))
    RuleBasedIrrigationData<-fromJSON(file.path(input_file_dir,"RuleBasedIrrigationData.json",fsep = .Platform$file.sep))
    SoilProfile<-fromJSON(file.path(input_file_dir,"SoilProfile.json",fsep = .Platform$file.sep))
    VineYardData<-fromJSON(file.path(input_file_dir,"VineYardData.json",fsep = .Platform$file.sep))
    Control<-fromJSON(file.path(input_file_dir,"control.json",fsep = .Platform$file.sep))

    ObservedIrrigationTimeseries<-read.csv(file.path(input_file_dir,"ObservedIrrigation.csv",fsep = .Platform$file.sep))
    Weatherfile<-read.csv(file.path(input_file_dir,"MILD.csv",fsep = .Platform$file.sep)) #paste0(...)

    if(file.exists(file.path(input_file_dir, "obs_irrig.csv"))){
      print(paste("using observed irrigation file..."))
      use_obs_irrig<-TRUE
      obs_irrig<-read.csv(file.path(input_file_dir,"obs_irrig.csv",fsep = .Platform$file.sep))
      #print(paste(obs_irrig))
    }
    else{use_obs_irrig<-FALSE}
  } else {
    BerryCultivar<-fromJSON(system.file("extdata","BerryCultivar.json",package="VineLOGIC"))
    Cultivar<-fromJSON(system.file("extdata","Cultivar.json",package="VineLOGIC"))
    HarvestControl<-fromJSON(system.file("extdata","HarvestControl.json",package="VineLOGIC"))
    HydrologyParameters<-fromJSON(system.file("extdata","HydrologyParameters.json",package="VineLOGIC"))
    InitialSoilConditions<-fromJSON(system.file("extdata","InitialSoilConditions.json",package="VineLOGIC"))
    ObservedIrrigation<-fromJSON(system.file("extdata","ObservedIrrigation.json",package="VineLOGIC"))
    Rootstock<-fromJSON(system.file("extdata","Rootstock.json",package="VineLOGIC"))
    RuleBasedIrrigationData<-fromJSON(system.file("extdata","RuleBasedIrrigationData.json",package="VineLOGIC"))
    SoilProfile<-fromJSON(system.file("extdata","SoilProfile.json",package="VineLOGIC"))
    VineYardData<-fromJSON(system.file("extdata","VineYardData.json",package="VineLOGIC"))
    Control<-fromJSON(system.file("parameters","control.json",package="VineLOGIC"))

    ObservedIrrigationTimeseries<-read.csv(system.file("extdata","ObservedIrrigation.csv",package="VineLOGIC"))
    Weatherfile<-read.csv(system.file("extdata","MILD.csv",package="VineLOGIC"))
  }

  summary_output_variables<-list()  # tracking summary variables

  Weatherfile$Date<-as.Date(Weatherfile$Date,format="%d/%m/%Y")
  #initialweather<-read_daily_weather(start_date,Weatherfile)

  Iirri<-'A'
  MeEvp<-'R'
  ##########################################
  ### Hard coded variable initialisation ###
  ##########################################

  #Irrigation
  NARW<-0
  Nap<-0
  JULAPL<-rep(0,150)
  AMIR<-rep(0,150)
  TOTAPW<-0
  TOTIR  <- 0.0
  #for (i in 1:ObservedIrrigation$NIRR$Value){
   # JULAPL[i]<-ObservedIrrigationTimeseries$Date[i]
    #AMIR[i]<-ObservedIrrigationTimeseries$Amount.of.irrigaiton[i]
    #print(paste("i", i))
    #print(paste("TOTAPW", TOTAPW))
    #print(paste("JULAPL[i]", JULAPL[i]))
    #print(paste("AMIR[i]", AMIR[i]))
    #TOTAPW<-TOTAPW+AMIR[i]
  #}
  #print(paste("total TOTAPW", TOTAPW))
  CumIRRStage<-rep(0,10)
  CumNetET<-0
  LastIRDoy<-0

  #Hydrology
  if(HydrologyParameters$BotBoundFlux$Value!=0.0){SoilProfile$SoilLayerProperties$SSKS$Value[15]<-HydrologyParameters$BotBoundFlux$Value}

  #growth stages
  Cultivar$P1VV$Value<-Cultivar$P1VV$Value*0.0054545+0.0003  # MJK: TODO: Check
  LastLeaf<-1
  LeafDays<-1
  LeafMassLoss<-0
  VinesSqm<- 1.0 / (VineYardData$VINEROWSPC$Value*VineYardData$INTERVINEDIST$Value)
  LatNo <- 1.0
  TMFAC1<-rep(0,8)
  for(i in 1:8){
    TMFAC1[i] <- 0.931 + 0.114*i-0.0703*i**2+0.0053*i**3
  }
  TBASE <-Control$Tbase$Value

  #stress indicies
  Swdf1<-1.0
  Swdf2<-1.0
  Saf1 <-1.0
  Saf2<-1.0
  SaltIndex<-1.0
  Saltgr<-1.0

  #Soil layers
  NLAYR<-length(SoilProfile$SoilLayerProperties$Layer$Value)
  # for(i in 1:NLAYR){
  #   if(i<=3){
  #     if(InitialSoilConditions$InitialSoilWater$Value[i]>SoilProfile$SoilLayerProperties$SDUL$Value[i]){InitialSoilConditions$InitialSoilWater$Value[i]<-SoilProfile$SoilLayerProperties$SDUL$Value[i]}
  #     if(InitialSoilConditions$InitialSoilWater$Value[i]<SoilProfile$SoilLayerProperties$SLLL$Value[i]){InitialSoilConditions$InitialSoilWater$Value[i]<-SoilProfile$SoilLayerProperties$SLLL$Value[i]}
  #   } else {
  #     if(InitialSoilConditions$InitialSoilWater$Value[i]>SoilProfile$SoilLayerProperties$SSAT$Value[i]){InitialSoilConditions$InitialSoilWater$Value[i]<-SoilProfile$SoilLayerProperties$SSAT$Value[i]}
  #     if(InitialSoilConditions$InitialSoilWater$Value[i]<SoilProfile$SoilLayerProperties$SLLL$Value[i]){InitialSoilConditions$InitialSoilWater$Value[i]<-SoilProfile$SoilLayerProperties$SLLL$Value[i]}
  #   }
  # }
  SoilLayerDepth<-rep(NA,NLAYR)
  if(NLAYR>1){
    for(i in 2:NLAYR){
      SoilLayerDepth[i]<-SoilProfile$SoilLayerProperties$Layer$Value[i]-SoilProfile$SoilLayerProperties$Layer$Value[i-1]
    }
  }
  SoilLayerDepth[1]<-SoilProfile$SoilLayerProperties$Layer$Value[1]

  #Soil water
  Tsw<-0
  Cumdep<-0
  Esw<-Sw<-DL2<-DL1<-Rwu<-Flowd<-Flowu<-rep(NA,NLAYR)
  SwYest<-rep(NA,NLAYR)
  Ad<-rep(NA,3)
  for (i in 1:NLAYR){
    Esw[i]<-(SoilProfile$SoilLayerProperties$SDUL$Value[i]*Control$SDULMult$Value)-(SoilProfile$SoilLayerProperties$SLLL$Value[i]*Control$SLLLMult$Value)  # MJK: added mult par in control.json here
    Sw[i]<-InitialSoilConditions$InitialSoilWater$Value[i]*Control$InitialSoilWaterMult$Value  # MJK: added mult par in control.json here
    if(i<=3){Ad[i]<-SoilProfile$SoilLayerProperties$SLLL$Value[i]*Control$SLLLMult$Value*0.5}  # MJK: added mult par in control.json here
    Cumdep<-Cumdep+SoilLayerDepth[i]
    DL2[i]<-Cumdep
    DL1[i]<-Cumdep-SoilLayerDepth[i]
    Rwu[i]<-0
    Flowd[i]<-0
    Flowu[i]<-0
    Tsw<-Tsw+InitialSoilConditions$InitialSoilWater$Value[i]*SoilLayerDepth[i]
    #Swinitial<-Sat
  }
  if(SoilProfile$KSMX$Value==0){SoilProfile$KSMX$Value<-0.5*SoilProfile$SoilLayerProperties$SSKS$Value[1]*Control$SSKSMult$Value}  # MJK: added mult par from control.json here

  CritWFPS<-Control$CritWFPS$Value
  Ilatime<-TotalPorosity<-SatWFPS<-Lazfact<-Laf1<-Aerf<-rep(NA,NLAYR)
  for (i in 1:NLAYR){
    Ilatime[i]<-0
    Lazfact[i]<-1.0
    if(DL2[i]>50){Lazfact[i]<-50/(DL2[i]-0.5*SoilLayerDepth[i])}
    TotalPorosity[i]<-1.0-(SoilProfile$SoilLayerProperties$SBDM$Value[i]*Control$SBDMMult$Value)/2.65  # MJK: added mult par from control.json here
    SatWFPS[i]<-(SoilProfile$SoilLayerProperties$SSAT$Value[i]*Control$SSATMult$Value)/TotalPorosity[i]  # MJK: added mult par from control.json here
    Laf1[i]<-1.0
  }

  #Roots
  RLV<-rep(0,NLAYR)
  for(i in 1:NLAYR){
    RLV[i] <- 3.0*SoilProfile$SoilLayerProperties$SRGF$Value[i]*Control$SRGFMult$Value  # MJK: added mult par from control.json here
  }

  Rootdw<-Control$RootDwFrac$Value*VineYardData$TRUNKDW$Value
  RootCho<-Control$RootCho$Value
  RstockVigIndex<-(Rootstock$RstockVigIndex$Value/9)*2
  RelativeAreationSensitivity<-Rootstock$RstockAernSens$Value/9
  MaxRootDepth<-Control$MaxRootDepth$Value
  LeafEnvelopeAdj<-1+0.1*((Rootstock$RstockVigIndex$Value/9)-0.5)
  SpecLeafAreaAdj<-1+0.1*((Rootstock$RstockVigIndex$Value/9)-0.5)

  Cumdep<-0
  Trlv<-0
  for(i in 1:NLAYR){
    if(SoilProfile$SoilLayerProperties$SRGF$Value[i]*Control$SRGFMult$Value>0){  # MJK: added mult par from control.json here
      Cumdep<-Cumdep+SoilLayerDepth[i]
      if(Cumdep<=10){SoilProfile$SoilLayerProperties$SRGF$Value[i]<-SoilProfile$SoilLayerProperties$SRGF$Value[i]*0.4}
      if(Cumdep>MaxRootDepth && MaxRootDepth!=0){SoilProfile$SoilLayerProperties$SRGF$Value[i]<-0}
      if(SoilProfile$SoilLayerProperties$SRGF$Value[i]*Control$SRGFMult$Value!=0){  # MJK: added mult par from control.json here
        Rootdepth<-Cumdep
        LastLayerRootZone<-i
      }
      RLV[i]<-SoilProfile$SoilLayerProperties$SRGF$Value[i]*Control$SRGFMult$Value*(1+((RstockVigIndex/9-0.5)*0.2))  # MJK: added mult par from control.json here
      if(Cumdep<=20){RLV[i]<-RLV[i]*0.1}
    } else {
      RLV[i]<-0
    }
    Trlv<-Trlv+RLV[i]
  }

  ###########################################################
  ### Declare state variables for output before main loop ###
  ###########################################################

  state_variables<-data.frame(DayOfYear<-seq(as.Date(start_date),(as.Date(start_date)+sim_length-1),"day"))
  names(state_variables)<-c("DayOfYear")

  state_variables$Tmean<-rep(0,sim_length)
  state_variables$daily_thermal_time<-rep(0,sim_length)
  state_variables$cumul_thermal_time<-rep(0,sim_length)
  state_variables$cumul_thermal_time_dormancy<-rep(0,sim_length)
  state_variables$cumul_vern_days<-rep(0,sim_length)
  state_variables$vern_fac<-rep(0,sim_length)
  state_variables$Berry_thermal_time<-rep(0,sim_length)
  state_variables$sum_daily_thermal_time<-rep(0,sim_length)
  state_variables$days_since_bud_burst<-rep(0,sim_length)
  state_variables$Matdtt<-rep(0,sim_length)
  state_variables$FFulindex<-rep(0,sim_length)
  state_variables$iStage<-rep(0,sim_length)

  state_variables$Vcarbo<-rep(0,sim_length)
  state_variables$Pcarb<-rep(0,sim_length)
  state_variables$Vreserve<-rep(0,sim_length)
  state_variables$aeration_stress<-rep(0,sim_length)
  state_variables$soil_water_stress1<-rep(0,sim_length)
  state_variables$soil_water_stress2<-rep(0,sim_length)
  state_variables$Cpool<-rep(0,sim_length)
  state_variables$vcarbo_limits_swdf<-rep(0,sim_length)
  state_variables$vcarbo_limits_air<-rep(0,sim_length)
  state_variables$vcarbo_limits_salt<-rep(0,sim_length)

  state_variables$shoot_num<-rep(0,sim_length)
  state_variables$berry_num_shoot<-rep(0,sim_length)
  state_variables$berry_num_vine<-rep(0,sim_length)
  state_variables$BerryDw<-rep(0,sim_length)
  state_variables$SugarDw<-rep(0,sim_length)
  state_variables$FruitDw<-rep(0,sim_length)
  state_variables$BerryStage<-rep(0,sim_length)
  state_variables$Brix<-rep(0,sim_length)
  state_variables$FruitSink<-rep(0, sim_length)
  #state_variables$FruitFreshWt<-rep(0, sim_length)

  state_variables$VLeafwt<-rep(0,sim_length)
  state_variables$VStemwt<-rep(0,sim_length)
  state_variables$VRootwt<-rep(0,sim_length)
  state_variables$root_growth<-rep(0,sim_length)
  state_variables$stem_growth<-rep(0,sim_length)
  state_variables$leaf_growth<-rep(0,sim_length)
  state_variables$LAI<-rep(0,sim_length)
  state_variables$LatNo<-rep(0,sim_length)
  state_variables$shoot_sqm<-rep(0,sim_length)

  #state_variables$Vcangro_shootno<-rep(0,sim_length)
  #state_variables$Vcangro_ShootSqm<-rep(0,sim_length)
  #state_variables$Vcangro_vla<-rep(0,sim_length)

  state_variables$VineEop<-rep(0,sim_length)
  state_variables$Tru<-rep(0,sim_length)
  #state_variables$TruForSwdf<-rep(0,sim_length)
  #state_variables$EopForSwdf<-rep(0,sim_length)
  state_variables$BUDNOVINE<-rep(0,sim_length)

  state_variables$total_soil_water1<-rep(0,sim_length)
  state_variables$total_soil_water2<-rep(0,sim_length)
  state_variables$rain<-rep(0,sim_length)
  state_variables$ponding<-rep(0,sim_length)
  state_variables$irrigation<-rep(0,sim_length)
  state_variables$drainage<-rep(0,sim_length)
  state_variables$root_uptake<-rep(0,sim_length)
  state_variables$evap<-rep(0,sim_length)
  state_variables$transp<-rep(0,sim_length)
  state_variables$Pesw<-rep(0,sim_length)
  state_variables$water_table<-rep(0,sim_length)
  state_variables$pot_et<-rep(0,sim_length)

  state_variables$ATheta<-rep(0,sim_length)
  state_variables$TswTop<-rep(0,sim_length)
  state_variables$Wet1<-rep(0,sim_length)
  state_variables$soil_water_deficit<-rep(0,sim_length)
  state_variables$soil_water<-rep(0,sim_length)
  state_variables$soil_water_top<-rep(0,sim_length)
  state_variables$soil_water_mid<-rep(0,sim_length)
  state_variables$soil_water_bot<-rep(0,sim_length)
  state_variables$soil_water_sat_prop<-rep(0,sim_length)
  state_variables$infiltration<-rep(0,sim_length)
  state_variables$runoff<-rep(0,sim_length)
  state_variables$salt_stress1<-rep(0,sim_length)
  state_variables$salt_stress2<-rep(0,sim_length)
  state_variables$IRCRITSW<-rep(0,sim_length)
  state_variables$soil_water_balance<-rep(0,sim_length)
  state_variables$da_initial_lai<-rep(0,sim_length)

  ##########################################
  ### Initialisation of global variables ###
  ##########################################

  BerryThermalTime<-0
  Date<-start_date
  iStage<-10
  SumDTT<-0

  growth_stage_controls<-list()
  growth_stage_controls$CumDu<-0
  growth_stage_controls$CumVD<-0
  growth_stage_controls$StartSenstiveStage<-0
  growth_stage_controls$Setdd<-Control$Setdd$Value
  growth_stage_controls$DaysSinceBudBurst<-0
  growth_stage_controls$Cumdtt<-0
  growth_stage_controls$VF<-0
  growth_stage_controls$Cumph<-0
  growth_stage_controls$LeafDurMin<-0.85*(Cultivar$P3FF$Value+growth_stage_controls$Setdd+Cultivar$P4HH$Value)
  growth_stage_controls$Matdtt<-0
  growth_stage_controls$Mature<-0

  FF_Index<-list()
  FF_Index$C1<-1
  FF_Index$S1<-0
  FF_Index$fruit_index_1<-0
  FF_Index$fruit_index_2<-0
  FF_Index$FFulindex<-0
  FF_Index$bud_fert_index<-1
  # S1     <- sin(XLAT*0.01745) #This is intended code, but XLAT not initialised in VineLOGIC and therefore this is zero Culley 2020
  # C1     <- cos(XLAT*0.01745)

  Rquotient_counters<-list()
  Rquotient_counters$CumRadn<-0
  Rquotient_counters$CumStagDtt<-0
  Rquotient_counters$CumStagdtt2<-0
  Rquotient_counters$CumIparPot<-0
  Rquotient_counters$CumIparStr<-0
  Rquotient_counters$CumRadndtt<-0
  Rquotient_counters$Rdtt2<-0

  hydrology<-list()
  hydrology$PiezHead<-0
  hydrology$Potet<-0
  hydrology$Pond<-0
  hydrology$Runoff<-0
  hydrology$Drain<-0
  hydrology$TruDepwt<-HydrologyParameters$TruDepWt$Value*100
  hydrology$Inflow<--1*SoilProfile$SoilLayerProperties$SSKS$Value[NLAYR]*Control$SSKSMult$Value  # MJK: added mult par from control.json here
  hydrology$Outflow<-SoilProfile$SoilLayerProperties$SSKS$Value[NLAYR]*Control$SSKSMult$Value  # MJK: added mult par from control.json here

  berry_growth<-list()
  berry_growth$CumBerryDtt<-0
  berry_growth$CumTmax<-0
  berry_growth$CumSwd<-0
  berry_growth$AnthoTempSensDays<-0
  berry_growth$Brix<-0
  berry_growth$DelBerryDw<-0
  berry_growth$DelSugarDw<-0
  berry_growth$FruitSink<-0
  berry_growth$BerryDw<-0
  berry_growth$SugarDw<-0
  berry_growth$FruitDw<-0
  berry_growth$BerryStage<-0
  #berry_growth$FruitFreshWt<-0
  #FruitFreshWt<-0

  energy_store<-list()
  energy_store$Vcarbo<-0
  energy_store$Pcarb<-0
  energy_store$Setreserve<-0
  energy_store$Vreserve<-VineYardData$TRUNKDW$Value*VineYardData$TRUNKCHO$Value+Rootdw*RootCho  #MJK: TODO: add units to json
  energy_store$VreserveMin<-VineYardData$TRUNKDW$Value*40+Rootdw*55
  energy_store$Cpool<-0
  energy_store$Pwood<-0

  berry_counts<-list()
  berry_counts$single_shoot_wt<-0
  berry_counts$shoot_num<-0
  berry_counts$berry_num_shoots<-0
  berry_counts$berry_num_vines<-0
  berry_counts$berry_num_adj<-1
  berry_counts$bunch_num_shoots<-0
  berry_counts$bunch_num_adj<-1
  berry_counts$obs_berry_num_vine<-VineYardData$BUNCHNOVINE$Value*VineYardData$BERRYBUNCH$Value
  berry_counts$use_obs<-TRUE  ## MJK: TODO: parameterization: add to control.json

  canopy_growth<-list()
  canopy_growth$CanAgeDtt<-rep(0,366)
  canopy_growth$DelLAIStore<-rep(0,365)
  canopy_growth$VLeafwt  <- 0
  canopy_growth$VStemwt  <- 0
  canopy_growth$VRootwt  <- 0
  canopy_growth$VgroFruit<-0.0
  canopy_growth$VgroRes<-0.0

  VineEop<-0.0
  Tru<-0.0

  # for seq DA efficiency
  if(!is.null(da_cycle)){
    if(da_cycle>0){
    f<-sprintf("pest.global.%d.oe.csv", da_cycle-1)
    fname<-file.path("..", "master", f)
    print(paste("reading observation ensemble file for data assimilation..."))
    oe<-read.csv(fname, check.names=FALSE)[sprintf("%d", real_idx+1),]
    print(paste("... done"))
    }
  }

  num_trims=0  # for canopy intervention   # MJK: should track this as state..

  ################################################################################################################################
  #####################################                     MAIN LOOP                     ########################################
  ################################################################################################################################
  for (j in 1:sim_length){
    Datedata<-as.POSIXlt(Date)
    DOY<-Datedata$yday+1 #yday is zero based
    index<-as.numeric(as.Date(Date)-as.Date(start_date)+1)
    #print(paste("index", index))

    #####################
    ###    For DA     ###
    #####################
    if(!is.null(da_cycle)){
      if(index-1<da_cycle){  # prior to curr cycle
        #fname<-sprintf("lai_state_passed_to_VL_%d.csv", index-1)  # assumes same real - need more flexibility re parallelized realizations # make obs
        #LAI<-read.csv(fname)[[2]]
        #f<-sprintf("pest.global.%d.oe.csv", da_cycle-1)
        #fname<-file.path("..","master", f)
        obs<-sprintf("%d_lai", index)
        #LAI<-read.csv(fname,check.names = FALSE)[[obs]][[real_idx+1]]
        LAI<-oe[[obs]]
        print(paste("read lai state variables from",fname,"as input...:",LAI))
        #state_variables$da_initial_lai[index-1]<-LAI

        Vla<-LAI/(VinesSqm*0.0001)  # vine leaf area - which features in regulating growth (Slag, Vlag)


        # sm states too  # TODO: have dynamic condition for entering this block
        #soil_water<-oe[[sprintf("%d_swave", index)]]
        #soil_water_top<-oe[[sprintf("%d_swt", index)]]
        #soil_water_mid<-oe[[sprintf("%d_swm", index)]]
        #soil_water_bot<-oe[[sprintf("%d_swb", index)]]
      }
      else if(index-1==da_cycle){  # curr cycle
        fname<-"lai_states_in.csv"
        LAI<-read.csv(fname)[[2]]  #$LAI
        print(paste("read lai state variables from",fname,"as input...:",LAI))
        #state_variables$da_initial_lai[index-1]<-LAI
        #fname1<-sprintf("lai_state_passed_to_VL_%d.csv", index-1)
        #write.csv(LAI, fname1)

        Vla<-LAI/(VinesSqm*0.0001)  # vine leaf area - which features in regulating growth (Slag, Vlag)

        # sm states too  # TODO: have dynamic condition for entering this block
        #soil_water<-read.csv("swave_states_in.csv")[[2]]
        #soil_water_top<-read.csv("swt_states_in.csv")[[2]]
        #soil_water_mid<-read.csv("swm_states_in.csv")[[2]]
        #soil_water_bot<-read.csv("swb_states_in.csv")[[2]]
      }
      # time index ahead of current cycle is done internally below
    }

    #####################
    ### Daily Weather ###
    #####################
    DailyWeather<-read_daily_weather(Date,Weatherfile)
    #print(paste("DailyWeather",DailyWeather))
    state_variables$Tmean[index]<-DailyWeather$Tmean
    state_variables$rain[index]<-DailyWeather$Rain
    state_variables$IRCRITSW[index]<-0.0  # replaced below
    #print(paste("...solving day...",index))
    #####################
    ### Water Balance ###
    #####################
    if(iStage>=2 && iStage <=7){
      Tru<-0
      Pinf<-0
      IrrigToday<-0

      if(Iirri=='A' || Iirri=='F'){
        IrrDemandOutput<-calc_irrigation_demand(RuleBasedIrrigationData = RuleBasedIrrigationData,
                                                SoilLayerDepth = SoilLayerDepth,
                                                NLAYR = NLAYR,
                                                Sw = Sw,
                                                SoilProfile = SoilProfile,
                                                DailyWeather = DailyWeather,
                                                Potet = hydrology$Potet,
                                                CumNetET = CumNetET,
                                                iStage=iStage)
        CumNetET<-IrrDemandOutput$CumNetET
        ATheta<-IrrDemandOutput$ATheta
        TswTop<-IrrDemandOutput$TswTop
        Wet1<-IrrDemandOutput$Wet1
        SwDef<-IrrDemandOutput$Swdef
      }

      PiezLevel_output<-.Fortran('PiezLevel',Trudepwt=as.double(hydrology$TruDepwt),PiezHead<-as.double(hydrology$PiezHead),
                          KsMacro<-as.double(SoilProfile$SoilLayerProperties$SSKS$Value*Control$SSKSMult$Value),Nlayr<-as.integer(NLAYR),
                          Inflow<-as.double(hydrology$Inflow),Outflow<-as.double(hydrology$Outflow))  # MJK: added par mult from control.json here

      SoilProfile$SoilLayerProperties$SSKS$Value<-PiezLevel_output[[3]]  # MJK: added par mult from control.json here

      Caleo<-calc_evap(DailyWeather=DailyWeather,LAI=LAI+0.001,Salb=SoilProfile$SALB$Value)
      VineEop<-Caleo$VineEop
      #print(paste("VineEop from calc_evap", VineEop))
      Eos<-Caleo$Eos
      hydrology$Potet<-Caleo$Pot_ET

      Tsw1<-0
      for(i in 1:NLAYR){
        SwYest[i]<-Sw[i]
        Tsw1<-Tsw1+Sw[i]*SoilLayerDepth[i]
      }

      Depir<-0

      if(Iirri=='A' || Iirri=='F'){
        # combined observed and rule based functionality for DA
        # note ignoring ObservedIrrigation.json inputs here
        #if(!is.na(obs_irrig[index, 'irrigation'])){
         # print(paste("OBS IRR", obs_irrig[index, 'irrigation']))
          #oi<-obs_irrig[index, 'irrigation']
        #}
        #print(paste("days since BB:", growth_stage_controls$DaysSinceBudBurst))

        if(isTRUE(use_obs_irrig)){
          oi<-obs_irrig[index, 'irrigation']
        }
        else{
          oi<-FALSE
        }

        Irrig_output<-apply_automatic_irrigation(iStage=iStage,Date=Date,Depir=Depir,RuleBasedIrrigationData=RuleBasedIrrigationData,
                                                           CumIRRStage=CumIRRStage,CumNetET=CumNetET,Swdef=SwDef,LastIRDoy=LastIRDoy,JULAPL=JULAPL,AMIR=AMIR,Nap=Nap,Totir=TOTIR,ATheta=ATheta,oi=oi,Control=Control)

        LastIRDoy<-Irrig_output$LastIRDoy
        CumNetET<-Irrig_output$CumNetET
        Nap<-Irrig_output$Nap
        CumIRRStage<-Irrig_output$CumIRRStage
        Depir<-Irrig_output$Depir
        #print(paste("Depir", Depir))
        JULAPL<-Irrig_output$JULAPL
        AMIR<-Irrig_output$AMIR
        TOTIR<-Irrig_output$Totir


      } else {
        #Read observed irrigation
        Irrig_output<-read_daily_irrig(Date,ObservedIrrigationTimeseries)
        Depir<-Irrig_output$Depir
        #print(paste("Obsirr", Irrig_output))
        #JULAPL<-Irrig_output$JULAPL
        #AMIR<-Irrig_output$AMIR
        #TOTIR<-Irrig_output$Totir

      }
      if(Depir!=0){
        IrrigToday<-1
      }
      Precip<-((DailyWeather$Rain+Depir))/10

      Pondy<-hydrology$Pond
      Ponding<-.Fortran('Ponding', Pinf<-as.double(Pinf), Precip<-as.double(Precip), IrrigToday<-as.integer(IrrigToday),
                        Ksmtrx<-as.double(SoilProfile$KSMX$Value),Pond<-as.double(hydrology$Pond),sat<-as.double(SoilProfile$SoilLayerProperties$SSAT$Value*Control$SSATMult$Value),
                        sw<-as.double((Sw)),Nlayr<-as.double(NLAYR),Slope<-as.double(0),Pondmax<-as.double(SoilProfile$Pond$Value),
                        Runoff<-as.double(hydrology$Runoff),Ksmacro<-as.double(SoilProfile$SoilLayerProperties$SSKS$Value*Control$SSKSMult$Value))  # MJK: added mult pars from control.json here
      hydrology$Pond<-Ponding[[5]]
      hydrology$Runoff<-Ponding[[11]]
      Pinf<-Ponding[[1]]

      Drainage<-.Fortran('Drainage', Overflow<-as.double(0),Pinf<-as.double(Pinf),Nlayr<-as.integer(NLAYR),
                         Sw<-as.double(Sw),Dlayr<-as.double(SoilLayerDepth),Flowd<-as.double(Flowd),
                         DUL<-as.double(SoilProfile$SoilLayerProperties$SDUL$Value*Control$SDULMult$Value),Sat<-as.double(SoilProfile$SoilLayerProperties$SSAT$Value*Control$SSATMult$Value),
                         KsMacr0<-as.double(SoilProfile$SoilLayerProperties$SSKS$Value*Control$SSKSMult$Value),Drain<-as.double(hydrology$Drain))  # MJK: added mult pars from control.json here

      Flowd<-Drainage[[6]]
      Sw<-Drainage[[4]]
      hydrology$Drain<-Drainage[[10]]
      Overflow<-Drainage[[1]]


  #  If the drainage backup routine has caused water to backup to the surface
  #  put this in the pond and generate additional runoff if necessary.
      hydrology$Pond<-hydrology$Pond+Overflow
      if(hydrology$Pond>SoilProfile$Pond$Value){
        hydrology$Runoff<-hydrology$Runoff+hydrology$Pond-SoilProfile$Pond$Value
        hydrology$Pond<-SoilProfile$Pond$Value
      }
  #  If a pond is present evaporate water from there first
  #  Ef = Evaporation from flooded pond = floodwater in rice.
      Ef<-0
      if(hydrology$Pond>0){
        Ef<-Eos
        hydrology$Pond<-hydrology$Pond-Ef
        if(hydrology$Pond>0){
          Eos<-0
        } else {
          #Here the pond dried up and the Eo was partitioned between Ef and Eos.
          Eos<-0-hydrology$Pond
          Ef<-Ef-Eos
          hydrology$Pond<-0
        }
      }
      Upflow<-.Fortran('Upflow',PotSoilEvap<-as.double(Eos),ad<-as.double(Ad),Sw<-as.double(Sw),Nlayr<-as.integer(NLAYR),
                       Dlayr<-as.double(SoilLayerDepth),Sat<-as.double(SoilProfile$SoilLayerProperties$SSAT$Value*Control$SSATMult$Value),
                       Flowu<-as.double(Flowu),LL<-as.double(SoilProfile$SoilLayerProperties$SLLL$Value*Control$SLLLMult$Value),Es<-as.double(0))  # MJK: added mult pars in control.json here
      Es<-Upflow[[9]]
      Flowu<-Upflow[[7]]
      Sw<-Upflow[[3]]

      Es<-Es+Ef

      #if((index>680 & index<690)){print(paste("... idx", index, "Sw", Sw, "VineEop", VineEop, "RLV", RLV, "Swdf1", Swdf1, "Swdf2", Swdf2))}
      #if((index>680 & index<690)){print(paste("... date", Date, "Ep", Ep, "VineEop", VineEop, "Tru", Tru, "Swdf1", Swdf1))}#"Swdf2", Swdf2))}

      Wuptake<-.Fortran('Wuptake',Nlayr<-as.integer(NLAYR),Sw<-as.double(Sw),Dlayr<-as.double(SoilLayerDepth),VineEop<-as.double(VineEop),
                        LL<-as.double(SoilProfile$SoilLayerProperties$SLLL$Value*Control$SLLLMult$Value),RLV<-as.double(RLV),Swdf1<-as.double(Swdf1),Swdf2<-as.double(Swdf2),
                        Tru<-as.double(0),Ep<-as.double(0),TruForSwdf<-as.double(0),EopForSwdf<-as.double(0),CropFactMult<-as.double(Control$CropFactMult$Value))  # MJK: added mult par in control.json here
      ## MJK: parameterized crop factor in Wuptake above
      Swdf1<-Wuptake[[7]]
      Swdf2<-Wuptake[[8]]
      Sw<-Wuptake[[2]]
      Tru<-Wuptake[[9]]
      Ep<-Wuptake[[10]]
      llll<-Wuptake[[5]]

      VineEop<-Wuptake[[4]]
      RLV<-Wuptake[[6]]
      TruForSwdf<-Wuptake[[11]]
      EopForSwdf<-Wuptake[[12]]

      #print(paste("Tru", Tru))
      #print(paste("VineEop", VineEop * 0.7))
      #print(paste("Swdf1", Swdf1))
      #print(paste("Swdf2", Swdf2))

      #if((index>680 & index<690)){print(paste("idx", index, "Sw", Sw, "VineEop", VineEop, "RLV", RLV, "Swdf1", Swdf1, "Swdf2", Swdf2, "..."))}
      #if((index>680 & index<690)){print(paste("date", Date, "Ep", Ep, "VineEop", VineEop, "Tru", Tru, "Swdf1", Swdf1, "TruForSwdf", TruForSwdf, "..."))}#"Swdf2", Swdf2))}

      WatAdd<-0

      Eqwt<-.Fortran('Eqwt',WTlayr<-as.integer(0),Flowd<-as.double(Flowd),Nlayr<-as.integer(NLAYR),Flowu<-as.double(Flowu),
                     Sw<-as.double(Sw),Dul<-as.double(SoilProfile$SoilLayerProperties$SDUL$Value*Control$SDULMult$Value),Sat<-as.double(SoilProfile$SoilLayerProperties$SSAT$Value*Control$SSATMult$Value),
                     Dlayr<-as.double(SoilLayerDepth),Trudepwt<-as.double(hydrology$TruDepwt),DL2<-as.double(DL2))  # MJK: added mult par from control.json here
      hydrology$TruDepwt<-Eqwt[[9]]
      hydrology$PiezHead<-HydrologyParameters$TruDepWt$Value*100 #this is missed at the first time step and so im not sure this is intended
      Tsw2<-0
      for(i in 1:NLAYR){
        Tsw2<-Tsw2+Sw[i]*SoilLayerDepth[i]
      }
      SoilWaterBalance<-(Tsw1+DailyWeather$Rain*0.1+Pondy+Depir*0.1+WatAdd)-(Tsw2+hydrology$Pond+hydrology$Runoff+hydrology$Drain+Es+Tru)
      state_variables$soil_water_balance[index]<-SoilWaterBalance

      state_variables$total_soil_water1[index]<-Tsw1
      state_variables$total_soil_water2[index]<-Tsw2
      state_variables$ponding[index]<-hydrology$Pond
      state_variables$irrigation[index]<-Depir
      state_variables$drainage[index]<-hydrology$Drain
      state_variables$root_uptake[index]<-Tru
      state_variables$evap[index]<-Es
      state_variables$transp[index]<-Ep
      state_variables$pot_et[index]<-hydrology$Potet

      #state_variables$TruForSwdf[index]<-TruForSwdf
      #state_variables$EopForSwdf[index]<-EopForSwdf

      Pesw=0.0
      TotDrWater=0.0
      TotDrWaterUp=0.0
      TotHold=0.0
      for(i in 1:NLAYR){
        Pesw<-Pesw+SoilLayerDepth[i]*(Sw[i]-(SoilProfile$SoilLayerProperties$SLLL$Value[i]*Control$SLLLMult$Value))  # MJK: added mult par from control.json here

        if(Sw[i]>=SoilProfile$SoilLayerProperties$SDUL$Value[i]*Control$SDULMult$Value){  # MJK: added mult par from control.json here
          TotDrWater<-TotDrWater+SoilLayerDepth[i]*(Sw[i]-(SoilProfile$SoilLayerProperties$SDUL$Value[i]*Control$SDULMult$Value))  # MJK: added mult par from control.json here
        }
        if(Sw[i]>=SoilProfile$SoilLayerProperties$SDUL$Value[i]*Control$SDULMult$Value && DL2[i]<=hydrology$TruDepwt){  #MJK: added mult par from control.json here
          TotDrWaterUp<-TotDrWaterUp+SoilLayerDepth[i]*(Sw[i]-(SoilProfile$SoilLayerProperties$SDUL$Value[i]*Control$SDULMult$Value))  # MJK: added mult par from control.json here
          TotHold<-TotHold+SoilLayerDepth[i]*((SoilProfile$SoilLayerProperties$SSAT$Value[i]*Control$SSATMult$Value)-Sw[i])  # MJK: added mult par from control.json here
        }
      }
      state_variables$Pesw[index]<-Pesw
      state_variables$water_table[index]<-hydrology$TruDepwt

      state_variables$ATheta[index]<-ATheta
      state_variables$TswTop[index]<-TswTop
      state_variables$Wet1[index]<-Wet1
      state_variables$soil_water_deficit[index]<-SwDef
      state_variables$soil_water[index]<-mean(Sw[[2]],Sw[[4]],Sw[[6]],Sw[[7]],Sw[[8]],Sw[[9]],Sw[[10]],Sw[[11]],Sw[[12]],)
      state_variables$soil_water_top[index]<-mean(Sw[[2]],Sw[[4]],Sw[[6]])  #(Sw[[1]]
      state_variables$soil_water_mid[index]<-mean(Sw[[7]],Sw[[8]],Sw[[9]])  #8
      state_variables$soil_water_bot[index]<-mean(Sw[[10]],Sw[[11]],Sw[[12]])  #14
      state_variables$infiltration[index]<-Pinf
      state_variables$runoff[index]<-hydrology$Runoff
    }

    #####################
    ### Soil Aeration ###
    #####################
    SwWFPS_nlayr<-rep(0,NLAYR)
    if(iStage>=2 && iStage <=7){
      Saf1<-0
      Trlv<-sum(RLV)
      for(i in 1:NLAYR){
        if(i!=1){
          if(RLV[i]==0){
            break
          }
        }
        #Calculate an aeration factor (LaFact) for the layer based on the water filled pore space.
        SwWFPS<-Sw[i]/TotalPorosity[i]
        SwWFPS_nlayr[i]<-SwWFPS
        if(SwWFPS<CritWFPS){
          Lafact<-1
        } else {
          Lafact<-1-(SwWFPS-CritWFPS)/(SatWFPS[i]-CritWFPS)
        }
        #Modify this with an aeration factor dependent on depth (LazFact)
        Aerf[i]<-Lazfact[i]*Lafact

        #erf(L) will be 0 for deep wet soil layers and 1 for shallow dry
        #less than critical water filled pore space) soil layers.
        if(Aerf[i]<1){
          Ilatime[i]<-Ilatime[i]+1
          if(Ilatime[i]>60){Ilatime[i]<-60}

          if(Aerf[i]<1 && Ilatime[i]>3){
            Laf1[i]<-(1-((1-Aerf[i])**(Ilatime[i]**0.167)))*RelativeAreationSensitivity
            Laf1[i]<-min(Laf1[i],1)
            Laf1[i]<-max(Laf1[i],0)
          } else {
            Laf1[i]<-1
          }

        } else {
          Ilatime[i]<0
          Laf1[i]<-1
        }
        if(i>1 && Laf1[i]>Laf1[(i-1)]){Laf1[i]<-Laf1[(i-1)]}

        Saf1<-Saf1+(RLV[i]/Trlv)*min(1,Laf1[i])
      }
      Saf2<-Saf1
      state_variables$aeration_stress[index]<-Saf2
    }
    state_variables$soil_water_sat_prop[index]<-SwWFPS_nlayr


    ####################
    ### Thermal Time ###
    ####################
    DailyThermalTime<-daily_thermal_time(DailyWeather = DailyWeather,TMFAC1 = TMFAC1,TBASE = TBASE)
    state_variables$daily_thermal_time[index]<-DailyThermalTime

    BerryThermalTime<-DailyThermalTime-Control$BerryTTEarlyAdj$Value  # MJK: parameterized berry tt adj (=3)
    if(berry_growth$BerryStage>2){BerryThermalTime<-DailyThermalTime-Control$BerryTTLateAdj$Value}  # MJK: parameterized another berry tt adj (=5)
    if(BerryThermalTime<0){BerryThermalTime<-0}

    state_variables$Berry_thermal_time[index]<-BerryThermalTime

    SumDTT<-SumDTT+DailyThermalTime
    state_variables$sum_daily_thermal_time[index]<-SumDTT
    #####################################
    ### Check and change growth stage ###
    #####################################
    #print(paste(berry_counts$shoot_num))
    growth_stage_output<-growth_stage_management(iStage=iStage,growth_stage_controls=growth_stage_controls,DailyThermalTime=DailyThermalTime,DOY=DOY,FF_Index=FF_Index,Rquotient_counters=Rquotient_counters,energy_store<-energy_store,berry_counts=berry_counts,Cultivar=Cultivar,VineYardData=VineYardData,DailyWeather=DailyWeather)
    #print(paste(berry_counts$shoot_num))
    summary_output_variables<-append(summary_output_variables, growth_stage_output[[2]])
    growth_stage_output<-growth_stage_output[[1]]

    iStage<-growth_stage_output$iStage
    growth_stage_controls<-growth_stage_output$growth_stage_controls
    FF_Index<-growth_stage_output$FF_Index
    Rquotient_counters<-growth_stage_output$Rquotient_counters
    #print(paste("debug to here..."))
    berry_counts<-growth_stage_output$berry_counts

    state_variables$iStage[index]<-iStage
    state_variables$cumul_thermal_time[index]<-growth_stage_controls$Cumdtt
    state_variables$cumul_thermal_time_dormancy[index]<-growth_stage_controls$CumDu
    state_variables$cumul_vern_days[index]<-growth_stage_controls$CumVD
    state_variables$vern_fac[index]<-growth_stage_controls$VF
    state_variables$FFulindex[index]<-FF_Index$FFulindex
    state_variables$Matdtt[index]<-growth_stage_controls$Matdtt
    state_variables$days_since_bud_burst[index]<-growth_stage_controls$DaysSinceBudBurst

    ###############################
    ### Canopy and berry growth ###
    ###############################
    if(iStage>=2 && iStage <=7){
      #Initialise early growth numbers
      Clg<-80*LeafEnvelopeAdj  # MJK: free up this constant parameter of 80 (Clg - Constant for leaf growth  [maximum envelope value] - for computing individ leaf area)
      LeafDays<-LeafDays+1
      if(LeafDays>365){LeafDays<-1}
      for(i in 1:LeafDays){canopy_growth$CanAgeDtt[i]<-canopy_growth$CanAgeDtt[i]+DailyThermalTime}
      if(growth_stage_controls$DaysSinceBudBurst<=1){
        Vla<-VineYardData$BUDNOVINE$Value*0.1
        #print(paste("Vla", Vla, "VinesSqm", VinesSqm))
        LAI<-Vla*VinesSqm*0.0001
        VshootWt<-0.01
        # MJK: parameterize some of these fixed variables here?
        PercentBurst<-416*VineYardData$BUDNOVINE$Value**(-0.298)
        PercentBurst<-min(95,PercentBurst)
        PercentBurst<-max(PercentBurst,100)  # MJK
        berry_counts$shoot_num<-0.01*PercentBurst*VineYardData$BUDNOVINE$Value
        Egft<-1.2-0.0042*(DailyWeather$Tmean-17)**2
        Egft<-min(Egft,1)
        Egft<-max(Egft,0)
        DeadLeaf<-0

      }
      ShootSqm<-(berry_counts$shoot_num+LatNo)*VinesSqm
      #Calculate energy from light interception
      #print(paste("LAI from one day post BB for Interception..", LAI))
      # MJK: parameterizedd some fixed variables (e.g., those used to calc photosynthetically active radiation) as free
      #print(paste("pre-Interception, index, Vla:", index, Vla))
      #print(paste("LAI at Interception stage - index, iStage: ", index, iStage, LAI))
      Intercept<-.Fortran('Interception',LAI<-as.double(LAI),TrellisHt<-as.double(VineYardData$TRELLISHT$Value),
                          TrellisWD<-as.double(VineYardData$TRELLISWD$Value),VineRowSPc<-as.double(VineYardData$VINEROWSPC$Value),
                          SRAD<-as.double(DailyWeather$Srad),VINESSQM<-as.double(VinesSqm),Tmax<-as.double(DailyWeather$Tmax),
                          Tmin<-as.double(DailyWeather$Tmin),SWdf1<-as.double(Swdf1),Saf2<-as.double(Saf2),Saltgr<-as.double(Saltgr),
                          Vcarbo<-as.double(0),Pcarb<-as.double(0),TrellisMul<-as.double(0),PARFracMult<-as.double(Control$PARFracMult$Value))
      #vcarbo_limits_temp<-1.0-0.0025*((0.25*DailyWeather$Tmin+0.75*DailyWeather$Tmax)-26.0)**2
      #vcarbo_limits_temp<-max(vcarbo_limits_temp,0.0)
      #state_variables$vcarbo_limits_temp<-vcarbo_limits_temp
      state_variables$vcarbo_limits_swdf<-Intercept[[9]]
      state_variables$vcarbo_limits_air<-Intercept[[10]]
      state_variables$vcarbo_limits_salt<-Intercept[[11]]
      energy_store$Vcarbo<-Intercept[[12]]
      energy_store$Pcarb<-Intercept[[13]]
      if(berry_growth$BerryStage>1){energy_store$VreserveMin<-VineYardData$TRUNKDW$Value*20+Rootdw*35}
      if(energy_store$Vreserve*0.90>=energy_store$VreserveMin){
        AvailReserve<-(0.1*Control$PropAccessResvMult$Value)*energy_store$Vreserve  #MJK: parameterized access to reserve
        energy_store$Vreserve<-0.90*energy_store$Vreserve
      } else {
        AvailReserve<-0
      }
      Sreserve<-energy_store$Vreserve
      energy_store$Cpool<-AvailReserve+energy_store$Vcarbo

      DayPhylFrac<-DailyThermalTime/Cultivar$PHINT$Value
      #print(paste("DayPhylFrac, Cumph", DayPhylFrac, growth_stage_controls$Cumph))
      growth_stage_controls$Cumph<-growth_stage_controls$Cumph+DayPhylFrac
      Slag<-Clg*(growth_stage_controls$Cumph**(-0.7))*DayPhylFrac*min(Egft,Swdf2,SaltIndex,Saf2)
      Vgrostm<-0

      #Early post-budburst growth
      Early<-FALSE
      #print(paste("growth_stage_controls$Cumph, energy_store$Cpool", growth_stage_controls$Cumph, energy_store$Cpool))
      if(growth_stage_controls$Cumph<=0.5 && energy_store$Cpool!=0){  #MJK: changed Cumph from <=0.2 in concert with increasing PHINT for diff variety (!= Chard)... # TODO: check for alternative approach
        #print(paste("early catch, index, Slag:", index, Slag))
        Early<-TRUE
        Vlag<-Slag*berry_counts$shoot_num
        Vgrolf<-Vlag/(268*SpecLeafAreaAdj)
        Vgrostm<-0.25*Vgrolf
        Vgroshoots<-Vgrolf+Vgrostm
        Vgrort<-Vgroshoots*0.5
        VgroTot<-Vgroshoots+Vgrort
        if(energy_store$Cpool>VgroTot){
          energy_store$Cpool<-energy_store$Cpool-VgroTot
        } else {
          PoolFrac<-energy_store$Cpool/VgroTot
          Vlag<-Vlag*PoolFrac
          Vgrolf<-Vgrolf*PoolFrac
          Vgrostm<-Vgrostm*PoolFrac
          Vgrort<-Vgrort*PoolFrac
          Vgroshoots<-Vgroshoots*PoolFrac
          energy_store$Cpool<-0
        }
      }
      if(isFALSE(Early)){
        if(iStage<=3){
          #print(paste("cause of -LAI next day is because of -Vlag due to -SWDF2... Swdf2", Swdf2, "Swdf1", Swdf1))
          ###Vcangro
          #print(paste("pre-Vcangro (stage <=3), index, Vlag, Vla:", index, Vlag, Vla))
          # MJK: TODO: parameterize 0.7 in Vcangro?
          Vcangro_out<-.Fortran('Vcangro', LeafEnvelopeAdj<-as.double(LeafEnvelopeAdj), TempM<-as.double(DailyWeather$Tmean),
                            Vawr<-as.double(0),Cumph<-as.double(growth_stage_controls$Cumph),SpecLeafAreaAdj<-as.double(SpecLeafAreaAdj),
                            DayPhylFrac<-as.double(DayPhylFrac),Swdf2<-as.double(Swdf2),SaltIndex<-as.double(SaltIndex),
                            Saf2<-as.double(Saf2),shootno<-as.double(berry_counts$shoot_num),Vlag<-as.double(Vlag),ShootSqm<-as.double(ShootSqm),
                            Vgrolf<-as.double(Vgrolf),Vgrostm<-as.double(Vgrostm),Vgrort<-as.double(Vgrort),VgroTot<-as.double(VgroTot),
                            Vgroshoots<-as.double(Vgroshoots),Cpool<-as.double(energy_store$Cpool),PoolFrac<-as.double(0),
                            Latno<-as.double(LatNo),vla<-as.double(Vla))
          LatNo<-Vcangro_out[[20]]
          energy_store$Cpool<-Vcangro_out[[18]]
          Vgroshoots<-Vcangro_out[[17]]
          VgroTot<-Vcangro_out[[16]]
          Vgrort<-Vcangro_out[[15]]
          Vgrostm<-Vcangro_out[[14]]
          Vgrolf<-Vcangro_out[[13]]
          Vlag<-Vcangro_out[[11]]
          #print(paste("VLAG", Vlag))
          #MJK: temp hack
          #if(Vlag<0.0001){Vlag=1000}
          #print(paste("VLAG", Vlag))
          Vawr<-Vcangro_out[[3]]
          #Vcangro_shootno<-Vcangro_out[[11]]
          #Vcangro_ShootSqm<-Vcangro_out[[13]]
          #Vcangro_vla<-Vcangro_out[[21]]



        }
        if(iStage==3){
          berry_growth_out<-.Fortran('Begro',GcoefBeginVerdd<-as.double(BerryCultivar$BeginVerdd$Value),GcoefSetdd<-as.double(BerryCultivar$SetDD$Value),
                                     bdtt<-as.double(BerryThermalTime),CumBerryDtt<-as.double(berry_growth$CumBerryDtt),BerryStage<-as.integer(berry_growth$BerryStage),CumTmax<-as.double(berry_growth$CumTmax),CumSwd<-as.double(berry_growth$CumSwd),
                                     AnthoTempSensDays<-as.double(berry_growth$AnthoTempSensDays),Swdf2<-as.double(Swdf2),AnthoSensAvTmax<-as.double(0),Brix<-as.double(berry_growth$Brix),GcoefCritBrix<-as.double(BerryCultivar$critbrix$Value),
                                     DelBerryDw<-as.double(0),DelSugarDW<-as.double(0),GcoefBerryDw1<-as.double(BerryCultivar$dw1$Value),GcoefBerryDw2<-as.double(BerryCultivar$dw2$Value),
                                     FruitSink<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),Cpool<-as.double(energy_store$Cpool),BerryDw<-as.double(berry_growth$BerryDw),
                                     SugarDw<-as.double(berry_growth$SugarDw),FruitDw<-as.double(berry_growth$FruitDw),BerryWaterPercent<-as.double(0),
                                     BerryFreshWt<-as.double(0),FruitFreshWt<-as.double(0),BerryWaterContent<-as.double(0),TfColour<-as.double(0),SwdColour<-as.double(0),
                                     DelBerryAnthoMg1<-as.double(0),BerryAnthoMg2<-as.double(0),BerryAnthoMg3<-as.double(0),BerryAnthoConc<-as.double(0),Mature<-as.integer(0),TargetBrix<-as.double(HarvestControl$HarvestBrix$Value),Tmax<-as.double(DailyWeather$Tmax),
                                     GcoefAnthTss1<-as.double(BerryCultivar$banth$Value),GcoefAnthTss2<-as.double(BerryCultivar$canth$Value),
                                     DwCoeff3Mult<-as.double(Control$DwCoeff3Mult$Value),FruitSinkMult<-as.double(Control$FruitSinkMult$Value)) #MJK
          # MJK: parameterized coeffs in FruitSink calc
          berry_growth$CumBerryDtt<-berry_growth_out[[4]]
          berry_growth$CumTmax<-berry_growth_out[[6]]
          berry_growth$CumSwd<-berry_growth_out[[7]]
          berry_growth$AnthoTempSensDays<-berry_growth_out[[8]]
          berry_growth$Brix<-berry_growth_out[[11]]
          berry_growth$DelBerryDw<-berry_growth_out[[13]]
          berry_growth$DelSugarDw<-berry_growth_out[[14]]
          berry_growth$FruitSink<-berry_growth_out[[17]]
          berry_growth$BerryDw<-berry_growth_out[[20]]
          berry_growth$SugarDw<-berry_growth_out[[21]]
          berry_growth$FruitDw<-berry_growth_out[[22]]
          berry_growth$BerryStage<-berry_growth_out[[5]]
          growth_stage_controls$Mature<-berry_growth_out[[33]]
          energy_store$Cpool<-berry_growth_out[[19]]
          #FruitFreshWt<-berry_growth_out[[25]]
        }
        if(iStage==4){
          berry_growth_out<-.Fortran('Begro',GcoefBeginVerdd<-as.double(BerryCultivar$BeginVerdd$Value),GcoefSetdd<-as.double(BerryCultivar$SetDD$Value),
                                     bdtt<-as.double(BerryThermalTime),CumBerryDtt<-as.double(berry_growth$CumBerryDtt),BerryStage<-as.integer(berry_growth$BerryStage),CumTmax<-as.double(berry_growth$CumTmax),CumSwd<-as.double(berry_growth$CumSwd),
                                     AnthoTempSensDays<-as.double(berry_growth$AnthoTempSensDays),Swdf2<-as.double(Swdf2),AnthoSensAvTmax<-as.double(0),Brix<-as.double(berry_growth$Brix),GcoefCritBrix<-as.double(BerryCultivar$critbrix$Value),
                                     DelBerryDw<-as.double(0),DelSugarDW<-as.double(0),GcoefBerryDw1<-as.double(BerryCultivar$dw1$Value),GcoefBerryDw2<-as.double(BerryCultivar$dw2$Value),
                                     FruitSink<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),Cpool<-as.double(energy_store$Cpool),BerryDw<-as.double(berry_growth$BerryDw),
                                     SugarDw<-as.double(berry_growth$SugarDw),FruitDw<-as.double(berry_growth$FruitDw),BerryWaterPercent<-as.double(0),
                                     BerryFreshWt<-as.double(0),FruitFreshWt<-as.double(0),BerryWaterContent<-as.double(0),TfColour<-as.double(0),SwdColour<-as.double(0),
                                     DelBerryAnthoMg1<-as.double(0),BerryAnthoMg2<-as.double(0),BerryAnthoMg3<-as.double(0),BerryAnthoConc<-as.double(0),Mature<-as.integer(0),TargetBrix<-as.double(HarvestControl$HarvestBrix$Value),Tmax<-as.double(DailyWeather$Tmax),
                                     GcoefAnthTss1<-as.double(BerryCultivar$banth$Value),GcoefAnthTss2<-as.double(BerryCultivar$canth$Value),
                                     DwCoeff3Mult<-as.double(Control$DwCoeff3Mult$Value),FruitSinkMult<-as.double(Control$FruitSinkMult$Value)) #MJK
          # MJK: parameterized coeffs in FruitSink calc
          berry_growth$CumBerryDtt<-berry_growth_out[[4]]
          berry_growth$CumTmax<-berry_growth_out[[6]]
          berry_growth$CumSwd<-berry_growth_out[[7]]
          berry_growth$AnthoTempSensDays<-berry_growth_out[[8]]
          berry_growth$Brix<-berry_growth_out[[11]]
          berry_growth$DelBerryDw<-berry_growth_out[[13]]
          berry_growth$DelSugarDw<-berry_growth_out[[14]]
          berry_growth$FruitSink<-berry_growth_out[[17]]
          berry_growth$BerryDw<-berry_growth_out[[20]]
          berry_growth$SugarDw<-berry_growth_out[[21]]
          berry_growth$FruitDw<-berry_growth_out[[22]]
          berry_growth$BerryStage<-berry_growth_out[[5]]
          growth_stage_controls$Mature<-berry_growth_out[[33]]
          energy_store$Cpool<-berry_growth_out[[19]]
          #FruitFreshWt<-berry_growth_out[[25]]



          #print(paste("pre-Vcangro (stage 4), index, Vlag, Vla:", index, Vlag, Vla))
          # MJK: TODO: parameterize 0.7 in Vcangro?
          Vcangro_out<-.Fortran('Vcangro', LeafEnvelopeAdj<-as.double(LeafEnvelopeAdj), TempM<-as.double(DailyWeather$Tmean),
                                Vawr<-as.double(0),Cumph<-as.double(growth_stage_controls$Cumph),SpecLeafAreaAdj<-as.double(SpecLeafAreaAdj),
                                DayPhylFrac<-as.double(DayPhylFrac),Swdf2<-as.double(Swdf2),SaltIndex<-as.double(SaltIndex),
                                Saf2<-as.double(Saf2),shootno<-as.double(berry_counts$shoot_num),Vlag<-as.double(Vlag),ShootSqm<-as.double(ShootSqm),
                                Vgrolf<-as.double(Vgrolf),Vgrostm<-as.double(Vgrostm),Vgrort<-as.double(Vgrort),VgroTot<-as.double(VgroTot),
                                Vgroshoots<-as.double(Vgroshoots),Cpool<-as.double(energy_store$Cpool),PoolFrac<-as.double(0),
                                Latno<-as.double(LatNo),vla<-as.double(Vla))
          LatNo<-Vcangro_out[[20]]
          energy_store$Cpool<-Vcangro_out[[18]]
          Vgroshoots<-Vcangro_out[[17]]
          VgroTot<-Vcangro_out[[16]]
          Vgrort<-Vcangro_out[[15]]
          Vgrostm<-Vcangro_out[[14]]
          Vgrolf<-Vcangro_out[[13]]
          Vlag<-Vcangro_out[[11]]
          Vawr<-Vcangro_out[[3]]
          #Vcangro_shootno<-Vcangro_out[[11]]
          #Vcangro_ShootSqm<-Vcangro_out[[13]]
          #Vcangro_vla<-Vcangro_out[[21]]
        }
        if(iStage==5){
          berry_growth_out<-.Fortran('Begro',GcoefBeginVerdd<-as.double(BerryCultivar$BeginVerdd$Value),GcoefSetdd<-as.double(BerryCultivar$SetDD$Value),
                                     bdtt<-as.double(BerryThermalTime),CumBerryDtt<-as.double(berry_growth$CumBerryDtt),BerryStage<-as.integer(berry_growth$BerryStage),CumTmax<-as.double(berry_growth$CumTmax),CumSwd<-as.double(berry_growth$CumSwd),
                                     AnthoTempSensDays<-as.double(berry_growth$AnthoTempSensDays),Swdf2<-as.double(Swdf2),AnthoSensAvTmax<-as.double(0),Brix<-as.double(berry_growth$Brix),GcoefCritBrix<-as.double(BerryCultivar$critbrix$Value),
                                     DelBerryDw<-as.double(0),DelSugarDW<-as.double(0),GcoefBerryDw1<-as.double(BerryCultivar$dw1$Value),GcoefBerryDw2<-as.double(BerryCultivar$dw2$Value),
                                     FruitSink<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),Cpool<-as.double(energy_store$Cpool),BerryDw<-as.double(berry_growth$BerryDw),
                                     SugarDw<-as.double(berry_growth$SugarDw),FruitDw<-as.double(berry_growth$FruitDw),BerryWaterPercent<-as.double(0),
                                     BerryFreshWt<-as.double(0),FruitFreshWt<-as.double(0),BerryWaterContent<-as.double(0),TfColour<-as.double(0),SwdColour<-as.double(0),
                                     DelBerryAnthoMg1<-as.double(0),BerryAnthoMg2<-as.double(0),BerryAnthoMg3<-as.double(0),BerryAnthoConc<-as.double(0),Mature<-as.integer(0),TargetBrix<-as.double(HarvestControl$HarvestBrix$Value),Tmax<-as.double(DailyWeather$Tmax),
                                     GcoefAnthTss1<-as.double(BerryCultivar$banth$Value),GcoefAnthTss2<-as.double(BerryCultivar$canth$Value),
                                     DwCoeff3Mult<-as.double(Control$DwCoeff3Mult$Value),FruitSinkMult<-as.double(Control$FruitSinkMult$Value)) #MJK
          # MJK: parameterized coeffs in FruitSink calc
          berry_growth$CumBerryDtt<-berry_growth_out[[4]]
          berry_growth$CumTmax<-berry_growth_out[[6]]
          berry_growth$CumSwd<-berry_growth_out[[7]]
          berry_growth$AnthoTempSensDays<-berry_growth_out[[8]]
          berry_growth$Brix<-berry_growth_out[[11]]
          berry_growth$DelBerryDw<-berry_growth_out[[13]]
          berry_growth$DelSugarDw<-berry_growth_out[[14]]
          berry_growth$FruitSink<-berry_growth_out[[17]]
          berry_growth$BerryDw<-berry_growth_out[[20]]
          berry_growth$SugarDw<-berry_growth_out[[21]]
          berry_growth$FruitDw<-berry_growth_out[[22]]
          berry_growth$BerryStage<-berry_growth_out[[5]]
          growth_stage_controls$Mature<-berry_growth_out[[33]]
          energy_store$Cpool<-berry_growth_out[[19]]
          #FruitFreshWt<-berry_growth_out[[25]]
        }
        if(iStage==6){
          Vgrolf<-0
          Vgrostm<-0
          Vgroshoots<-0
          Vgrort<-0.15*energy_store$Vcarbo
          energy_store$Vcarbo<-energy_store$Vcarbo-Vgrort
          energy_store$Cpool<-energy_store$Cpool-Vgrort
        }
      }
      LeafMinTempI<-1
      if(iStage>=4 && DailyWeather$Tmin<=4){
        LeafMinTempI<-0.25+0.1875*DailyWeather$Tmin
      }
      LeafDurToday<-growth_stage_controls$LeafDurMin+0.25*growth_stage_controls$LeafDurMin*min(Swdf2,energy_store$Vreserve/100,SaltIndex,LeafMinTempI)
      # if(iStage>=4 && isTRUE(Frost)){
      #   LeafDurToday<-0
      #   growth_stage_controls$LeafDurMin<-0
      # }
      #print(paste("Vla", Vla, "Vlag", Vlag))
      if(SumDTT>growth_stage_controls$LeafDurMin){
        for(i in LastLeaf:LeafDays){
          if(canopy_growth$CanAgeDtt[i]>LeafDurToday){
            if(canopy_growth$DelLAIStore[i]>Vla){
              canopy_growth$DelLAIStore[i]<-Vla
              }
            Vla<-Vla-canopy_growth$DelLAIStore[i]
            #Senla<-Senla+DelLAIStore[i]
            LeafMassLoss<-canopy_growth$DelLAIStore[i]/Vawr
            canopy_growth$VLeafwt<-canopy_growth$VLeafwt-LeafMassLoss
            # if(isTRUE(Frost)){
            #   Vleafwt<-0
            #   Vla<-0
            #   Senla<-Senla+Vla
            # }
            LastLeaf<-LastLeaf+1
          }
        }
      }
      #print(paste("Vla", Vla, "Vlag", Vlag))
      Vla<-Vla+Vlag
      DeadLeaf<-DeadLeaf+LeafMassLoss
      canopy_growth$VLeafwt  <- canopy_growth$VLeafwt + Vgrolf
      canopy_growth$VStemwt  <- canopy_growth$VStemwt + Vgrostm
      canopy_growth$VRootwt  <- canopy_growth$VRootwt + Vgrort
      VShootwt <- canopy_growth$VStemwt+canopy_growth$VLeafwt+berry_growth$FruitDw
      energy_store$Cpool <- energy_store$Cpool + LeafMassLoss*0.20
      berry_counts$single_shoot_wt = VShootwt/berry_counts$shoot_num
      if(iStage>=5){
        VgroWood<-0.02*energy_store$Cpool
        energy_store$Pwood<-energy_store$Pwood+VgroWood
        energy_store$Cpool<-energy_store$Cpool*0.98
      }
      #print(paste("LAI i-2", LAI))
      #print(paste("Vla", Vla))
      LAI<-Vla*VinesSqm*0.0001
      #print(paste("LAI i-1", LAI))
      canopy_growth$DelLAIStore[LeafDays]<-Vlag
      VBiomas<-canopy_growth$VLeafwt+canopy_growth$VStemwt+berry_growth$FruitDw+DeadLeaf
      if(LAI>Control$maxLAI$Value){
        LAI<-Control$maxLAI$Value
        Vla<-LAI/(VinesSqm*0.0001)
      }  # MJK: reduces light interception but Vla, Vlag, etc not modified...


      # MJK: account for (uncertain) trimming practice including observed intervention
      #print(paste("num_trims", num_trims))
      #print(paste("LAI", LAI))

      do_trim=FALSE
      if(!is.null(da_cycle)){
        if((index-1 <= da_cycle) & (isTRUE(as.logical(Control$UseTrimObs$Value)))){
          if(as.Date(Date) %in% as.Date(Control$TrimDates$Value)){  # MJK: TrimDates could be an obs within PEST instead of a forcing variable...
            print(paste("DA,prev and now,in_dates,TrimRedLAI[num_trims]", Control$TrimRedLAI$Value[num_trims+1]))
            do_trim=TRUE
          }
        }
        else{
          #print(paste("LAI",LAI))
          #print(paste("num_trims",num_trims))
          #print(paste("length1",(length(Control$TrimTrigLAI$Value))))
          #print(paste("condition",(num_trims+1>length(Control$TrimTrigLAI$Value))))
          #print(paste("TrimTrig",Control$TrimTrigLAI$Value))
          #print(paste("current TrimTrig",Control$TrimTrigLAI$Value[num_trims+1]))
          #print(paste("current TrimRedLAI",Control$TrimRedLAI$Value[num_trims+1]))
          if(num_trims+1 > length(Control$TrimTrigLAI$Value)){
            print("using default trimming")
            if(LAI>3.0){
              do_trim=TRUE
              }
          }
          else{
            if(LAI>Control$TrimTrigLAI$Value[num_trims+1]){
            print(paste("DA,future,TrimRedLAI[num_trims]", Control$TrimRedLAI$Value[num_trims+1]))
            do_trim=TRUE
            }
          }
        }
      }
      else{
        if(isTRUE(as.logical(Control$UseTrimObs$Value))){
          if(as.Date(Date) %in% as.Date(Control$TrimDates$Value)){  # MJK: TrimDates could be an obs within PEST instead of a forcing variable...
            print(paste("noDA,in_date,TrimRedLAI[num_trims]", Control$TrimRedLAI$Value[num_trims+1]))
            do_trim=TRUE
          }
        }
        else{
          #print(do_trim)
          if(num_trims+1 > length(Control$TrimTrigLAI$Value)){
            print("using default trimming")
            if(LAI>3.0){
              do_trim=TRUE
            }
          }
          else{
            if(LAI>Control$TrimTrigLAI$Value[num_trims+1]){
              #print(do_trim)
              print(paste("noDA,TrimRedLAI[num_trims]", Control$TrimRedLAI$Value[num_trims+1]))
              do_trim=TRUE
            }
          }
        }
      }

      if(isTRUE(do_trim)){
        if(num_trims+1 > length(Control$TrimRedLAI$Value)){
          print("using default trimming")
          LAI<-LAI-1.0
        }
        else{
          LAI<-LAI-Control$TrimRedLAI$Value[num_trims+1]
        }
        num_trims=num_trims+1
        Vla<-LAI/(VinesSqm*0.0001)
      }
      # #print(paste("LAI, Vla at index, iStage: ", index, iStage, LAI, Vla))


      if(iStage>=6){
        Vlag<-0
        Vgrolf<-0
        Vgrostm<-0
        berry_growth$FruitSink<-0
        Vbiomas<-canopy_growth$VLeafwt+canopy_growth$VStemwt+DeadLeaf
      }
      if(iStage==7){
        canopy_growth$VLeafwt<-0
        LAI<-0
        Vla<-0
        state_variables$IRCRITSW[index]<-0.0
      }
      root_growth_out<-.Fortran('ROOTGR',GRORT<-as.double(Vgrort),RstockVigIndex<-as.double(RstockVigIndex),VineRtdep<-as.double(Rootdepth),
                                NLAYR<-as.integer(NLAYR),DLAYR<-as.double(SoilLayerDepth),Sw<-as.double(Sw),LL<-as.double(SoilProfile$SoilLayerProperties$SLLL$Value*Control$SLLLMult$Value),
                                Esw<-as.double(Esw),SHF<-as.double(SoilProfile$SoilLayerProperties$SRGF$Value*Control$SRGFMult$Value),RLV<-as.double(RLV))  # MJK: added mult pars from control.json here
      RLV<-root_growth_out[[10]]

      energy_store$Vreserve<-energy_store$Vreserve+energy_store$Cpool
      canopy_growth$VgroRes<-energy_store$Vreserve-Sreserve
      canopy_growth$VgroFruit<-berry_growth$FruitSink

      state_variables$Vcarbo[index]<-energy_store$Vcarbo
      state_variables$Pcarb[index]<-energy_store$Pcarb
      state_variables$Vreserve[index]<-energy_store$Vreserve
      state_variables$soil_water_stress1[index]<-Swdf1
      state_variables$soil_water_stress2[index]<-Swdf2
      state_variables$salt_stress1[index]<-SaltIndex
      state_variables$salt_stress2[index]<-Saltgr
      state_variables$shoot_num[index]<-berry_counts$shoot_num
      state_variables$berry_num_shoot[index]<-berry_counts$berry_num_shoots
      state_variables$berry_num_vine[index]<-berry_counts$berry_num_vines
      state_variables$Brix[index]<-berry_growth$Brix
      state_variables$BerryDw[index]<-berry_growth$BerryDw
      state_variables$SugarDw[index]<-berry_growth$SugarDw
      state_variables$FruitDw[index]<-berry_growth$FruitDw
      #state_variables$FruitFreshWt[index]<-FruitFreshWt
      state_variables$BerryStage[index]<-berry_growth$BerryStage
      state_variables$FruitSink[index]<-berry_growth$FruitSink
      state_variables$VLeafwt[index]<-canopy_growth$VLeafwt
      state_variables$VStemwt[index]<-canopy_growth$VStemwt
      state_variables$VRootwt[index]<-canopy_growth$VRootwt
      state_variables$root_growth[index]<-Vgrort
      state_variables$stem_growth[index]<-Vgrostm
      state_variables$leaf_growth[index]<-Vgrolf
      state_variables$LatNo[index]<-LatNo
      state_variables$shoot_sqm[index]<-ShootSqm
      state_variables$LAI[index]<-LAI
      state_variables$Cpool[index]<-energy_store$Cpool

      state_variables$VineEop[index]<-VineEop
      state_variables$Tru[index]<-Tru
      state_variables$IRCRITSW[index]<-1.0-(RuleBasedIrrigationData$IRCRITSW$Value[(iStage-1)]*0.01)

      #state_variables$Vcangro_shootno<-Vcangro_shootno
      #state_variables$Vcangro_ShootSqm<-Vcangro_ShootSqm
      #state_variables$Vcangro_vla<-Vcangro_vla
      state_variables$BUDNOVINE[index]<-VineYardData$BUDNOVINE$Value
    }

    if(iStage==7){
      state_variables$IRCRITSW[index]<-0.0
      break
    }
    Date<-as.Date(Date)+1
  }
  predicted_yield<-berry_growth$FruitDw*VinesSqm*10*4
  tot_ir<-TOTIR / 100.0
  print(paste("Applied Irrigation (ML/ha):", round(tot_ir,2)))
  print(paste("Predicted Yield (kg/ha):",round(predicted_yield,2)))
  #print(paste("Applied Irrigation (ML/ha):", round(tot_irrig,2)))
  summary_output_variables<-as.data.frame(summary_output_variables)
  summary_output_variables$Yield = round(predicted_yield,2)
  state_and_summary_variables<-list(state_variables, summary_output_variables)
  return(state_and_summary_variables)
  #plot(x=state_variables$DayOfYear,y=state_variables$LAI)
}

