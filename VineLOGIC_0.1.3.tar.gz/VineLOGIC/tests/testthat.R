# library(testthat)
# library(VineLOGIC)
#
# test_check("VineLOGIC")
#
#
