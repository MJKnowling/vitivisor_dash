#Created 3/04/2020

growth_stage_management<-function(iStage,growth_stage_controls,DailyThermalTime,DOY,FF_Index,Rquotient_counters,energy_store,berry_counts,Cultivar,VineYardData,DailyWeather){

  summary_output_variables<-list()  # tracking summary variables

  if(iStage==10){
    #Find end of endodormancy
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime #this shouldnt be here  ## MJK: TODO - but not affecting late phenological transitions
    Vern<-vernilisation_factor(DailyWeather=DailyWeather,VF=growth_stage_controls$VF,CumVD=growth_stage_controls$CumVD,Cultivar=Cultivar)
    growth_stage_controls$CumVD<-Vern$CumVD
    growth_stage_controls$VF<-Vern$VF
    growth_stage_controls$CumDu<-growth_stage_controls$CumDu+DailyThermalTime*growth_stage_controls$VF

    if(growth_stage_controls$CumDu>VineYardData$INCRITVD$Value && DOY>150){
      iStage<-11
      print(paste("Stage:",iStage,"    DOY:", DOY))
      print(paste("cumul thermal time (before end of endodormancy):", growth_stage_controls$CumDu))
      print(paste("cumul number of vernalisation days:", growth_stage_controls$CumVD))
      summary_output_variables$DOY11 = DOY
      growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime


    } else {
      growth_stage_controls$Cumdtt<-0
    }
  }

  if(iStage==11){
    #Find Budburst
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime

    if(growth_stage_controls$Cumdtt>Cultivar$P2BB$Value){
      growth_stage_controls$Cumdtt<-0
      iStage<-12
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY12 = DOY
    }

  }

  if(iStage==12){
    #Find bud sensitive stage
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime

    if(DOY<316 && growth_stage_controls$Cumdtt>=1100){
      growth_stage_controls$StartSenstiveStage<-316
    } else if (DOY>=316 && growth_stage_controls$Cumdtt>=1100){
      growth_stage_controls$StartSenstiveStage<-DOY
    } else if (DOY>=328){
      growth_stage_controls$StartSenstiveStage<-328
    }
    if(growth_stage_controls$StartSenstiveStage!=0){
      iStage<-13
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY13 = DOY
    }
  }

  if(iStage==13){
    #Find end of bud exposure period
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    if(DOY<=growth_stage_controls$StartSenstiveStage+19){
      FFindexCalc<-.Fortran('FFindexcal',Startsp<-as.integer(growth_stage_controls$StartSenstiveStage),DOY<-as.integer(DOY),
                            fruitIndex1<-as.double(FF_Index$fruit_index_1),fruitIndex2<-as.double(FF_Index$fruit_index_2),
                            S1<-as.double(FF_Index$S1),C1<-as.double(FF_Index$C1),Tmax<-as.double(DailyWeather$Tmax),SRAD<-as.double(DailyWeather$Srad),
                            FFulindex<-as.double(FF_Index$FFulindex))
      FF_Index$fruit_index_1<-FFindexCalc[[3]]
      FF_Index$fruit_index_2<-FFindexCalc[[4]]
      FF_Index$FFulindex<-FFindexCalc[[9]]


    }
    if(DOY==growth_stage_controls$StartSenstiveStage+19){
      iStage<-14
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY14 = DOY
      print(paste("FFindex: ",FFindexCalc[[9]]))
      summary_output_variables$FFindex = FFindexCalc[[9]]
    }
  }

  if(iStage==14){
    #Find harvest date for penultimate crop
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime

    if(growth_stage_controls$Cumdtt>(Cultivar$P2BB$Value+Cultivar$P3FF$Value+growth_stage_controls$Setdd+Cultivar$P4HH$Value)){
      iStage<-15
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY15 = DOY
    } #else if(DOY>120){  This is supposed to be day 120 of the next year
    #iStage<-15
      #print(DOY)
    #}
  }

  if(iStage==15){
    #Find leaf fall date
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime

    if(DOY>=135){#(DOY>=140){  ### MJK: squashing such that vernalisation (and subsequent EL stages) start sooner...
      iStage<-16
      print(paste("Stage (leaf fall by calendar):",iStage,"    DOY:", DOY))
      summary_output_variables$DOY16 = DOY

      output<-list()
      output$growth_stage_controls<-growth_stage_controls
      output$iStage<-iStage
      output$FF_Index<-FF_Index
      output$Rquotient_counters<-Rquotient_counters
      output$berry_counts<-berry_counts
      output_and_summary_variables<-list(output, summary_output_variables)
      return(output_and_summary_variables)
    } else if (growth_stage_controls$Cumdtt<(Cultivar$P2BB$Value+Cultivar$P3FF$Value+growth_stage_controls$Setdd+Cultivar$P4HH$Value+Cultivar$P5LF$Value)){

    } else {
      iStage<-16
      print(paste("Stage (leaf fall):",iStage,"    DOY:", DOY))
      summary_output_variables$DOY16 = DOY

      output<-list()
      output$growth_stage_controls<-growth_stage_controls
      output$iStage<-iStage
      output$FF_Index<-FF_Index
      output$Rquotient_counters<-Rquotient_counters
      output$berry_counts<-berry_counts
      output_and_summary_variables<-list(output, summary_output_variables)
      return(output_and_summary_variables)
    }
  }
  if(iStage==16){
    #Reset and switch to pre-season
    iStage<-8
    print(paste("Stage:",iStage,"    DOY:", DOY))
    summary_output_variables$DOY08 = DOY
    growth_stage_controls$CumDu<-0
    growth_stage_controls$CumVD<-0

    #If(Abs(Lat).ge.40.0)Cumdu=26! initialization to force earlier budburst in Tas (not currently added Culley 2020)
  }else if(iStage==8){
    #Find end of endodormancy
    Vern<-vernilisation_factor(DailyWeather=DailyWeather,VF=growth_stage_controls$VF,CumVD=growth_stage_controls$CumVD,Cultivar=Cultivar)
    growth_stage_controls$CumVD<-Vern$CumVD
    growth_stage_controls$VF<-Vern$VF
    growth_stage_controls$CumDu<-growth_stage_controls$CumDu+DailyThermalTime*growth_stage_controls$VF

    if(growth_stage_controls$CumDu>VineYardData$INCRITVD$Value && DOY>150){
      iStage<-1
      print(paste("cumul thermal time (before end of endodormancy):", growth_stage_controls$CumDu))
      print(paste("cumul number of vernalisation days:", growth_stage_controls$CumVD))
      #print(paste("vernalisation factor:", growth_stage_controls$VF))
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY01 = DOY

      ####This is incorrect but in here for consistency Culley 2020  ## TODO: MJK - don't aggregate cumdtt here
      growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime


    } else {
      growth_stage_controls$Cumdtt<-0
    }
  }else if(iStage==1){
    #Find Budburst
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime

    if(growth_stage_controls$Cumdtt>Cultivar$P2BB$Value || DOY>=290){
      growth_stage_controls$Cumdtt<-0
      iStage<-2
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY02 = DOY

      output<-list()
      output$growth_stage_controls<-growth_stage_controls
      output$iStage<-iStage
      output$FF_Index<-FF_Index
      output$Rquotient_counters<-Rquotient_counters
      output$berry_counts<-berry_counts
      output_and_summary_variables<-list(output, summary_output_variables)
      return(output_and_summary_variables)

    }
  }else if(iStage==2){
    #Find first flower
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    growth_stage_controls$DaysSinceBudBurst<- growth_stage_controls$DaysSinceBudBurst+1

    if(growth_stage_controls$Cumdtt>(Cultivar$P2BB$Value+Cultivar$P3FF$Value)){
      iStage<-3
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY03 = DOY
    }
  }else if(iStage==3){
    #Find end of fruit set period
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    #call Rquotient
    Rquotient_out<-.Fortran('RQuotient',RDtt2<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),CumRadn<-as.double(Rquotient_counters$CumRadn),
                            CumStagDtt<-as.double(Rquotient_counters$CumStagDtt),CumIparPot<-as.double(Rquotient_counters$CumIparPot),
                            CumIparStr<-as.double(Rquotient_counters$CumIparStr),Srad<-as.double(DailyWeather$Srad),Dtt<-as.double(DailyThermalTime),
                            Pcarb<-as.double(energy_store$Pcarb),Vcarbo<-as.double(energy_store$Vcarbo),Setreserve<-as.double(energy_store$Setreserve),
                            Vreserve<-as.double(energy_store$Vreserve),IParIndex<-as.double(0),CumRadnDtt<-as.double(Rquotient_counters$CumRadndtt))
    Rquotient_counters$Rdtt2<-Rquotient_out[[1]]
    Rquotient_counters$CumRadn<-Rquotient_out[[3]]
    Rquotient_counters$CumStagDtt<-Rquotient_out[[4]]
    Rquotient_counters$CumIparPot<-Rquotient_out[[5]]
    Rquotient_counters$CumIparStr<-Rquotient_out[[6]]
    Rquotient_counters$CumRadndtt<-Rquotient_out[[14]]
    Rquotient_counters$CumStagdtt2<-Rquotient_counters$CumStagdtt2+Rquotient_counters$Rdtt2


    if(growth_stage_controls$Cumdtt>(Cultivar$P2BB$Value+Cultivar$P3FF$Value+growth_stage_controls$Setdd)){
      iStage<-4
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY04 = DOY
      growth_stage_controls$Matdtt<-growth_stage_controls$Cumdtt
      Rquotient_counters$Cumradn=0.0
      Rquotient_counters$CumStagdtt=0.0
      Rquotient_counters$CumStagdtt2=0.0
      Rquotient_counters$CumRadnDtt=0.0
      Rquotient_counters$CumIparPot=0.0
      Rquotient_counters$CumIparStr=0.0
      energy_store$Setreserve=energy_store$Vreserve

      berry_counts$berry_num_shoots<-378*(1-0.8622*berry_counts$single_shoot_wt)*Cultivar$G1BN$Value*FF_Index$FFulindex*FF_Index$bud_fert_index
      berry_counts$berry_num_vines<-berry_counts$berry_num_shoots*berry_counts$shoot_num

      if(isTRUE(berry_counts$use_obs)){
        berry_counts$berry_num_vines<-berry_counts$obs_berry_num_vine
        berry_counts$berry_num_shoots<-berry_counts$obs_berry_num_vine/berry_counts$shoot_num
      }

      berry_counts$berry_num_shoots<-berry_counts$berry_num_shoots*berry_counts$berry_num_adj
      berry_counts$bunch_num_shoots<-1.49+0.002338*berry_counts$berry_num_shoots
      berry_counts$bunch_num_shoots<-berry_counts$bunch_num_shoots*berry_counts$bunch_num_adj
    } else {
      growth_stage_controls$DaysSinceBudBurst<- growth_stage_controls$DaysSinceBudBurst+1
    }

  }else if(iStage==4){
    #Find end of veraison
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    growth_stage_controls$DaysSinceBudBurst<- growth_stage_controls$DaysSinceBudBurst+1
    Rquotient_out<-.Fortran('RQuotient',RDtt2<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),CumRadn<-as.double(Rquotient_counters$CumRadn),
                            CumStagDtt<-as.double(Rquotient_counters$CumStagDtt),CumIparPot<-as.double(Rquotient_counters$CumIparPot),
                            CumIparStr<-as.double(Rquotient_counters$CumIparStr),Srad<-as.double(DailyWeather$Srad),Dtt<-as.double(DailyThermalTime),
                            Pcarb<-as.double(energy_store$Pcarb),Vcarbo<-as.double(energy_store$Vcarbo),Setreserve<-as.double(energy_store$Setreserve),
                            Vreserve<-as.double(energy_store$Vreserve),IParIndex<-as.double(0),CumRadnDtt<-as.double(Rquotient_counters$CumRadndtt))
    Rquotient_counters$Rdtt2<-Rquotient_out[[1]]
    Rquotient_counters$CumRadn<-Rquotient_out[[3]]
    Rquotient_counters$CumStagDtt<-Rquotient_out[[4]]
    Rquotient_counters$CumIparPot<-Rquotient_out[[5]]
    Rquotient_counters$CumIparStr<-Rquotient_out[[6]]
    Rquotient_counters$CumRadndtt<-Rquotient_out[[14]]
    growth_stage_controls$Matdtt<-growth_stage_controls$Matdtt+Rquotient_counters$Rdtt2
    if(growth_stage_controls$Matdtt>(Cultivar$P2BB$Value+Cultivar$P3FF$Value+growth_stage_controls$Setdd+Cultivar$P4HH$Value*0.5)){
      iStage<-5
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY05 = DOY
      #Record maximum LAI
      Rquotient_counters$Cumradn=0.0
      Rquotient_counters$CumStagdtt=0.0
      Rquotient_counters$CumStagdtt2=0.0
      Rquotient_counters$CumRadnDtt=0.0
      Rquotient_counters$CumIparPot=0.0
      Rquotient_counters$CumIparStr=0.0
    }
  }else if(iStage==5){
    #Find Harvest Date
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    growth_stage_controls$DaysSinceBudBurst<- growth_stage_controls$DaysSinceBudBurst+1
    Rquotient_out<-.Fortran('RQuotient',RDtt2<-as.double(0),BerryNoVine<-as.double(berry_counts$berry_num_vines),CumRadn<-as.double(Rquotient_counters$CumRadn),
                            CumStagDtt<-as.double(Rquotient_counters$CumStagDtt),CumIparPot<-as.double(Rquotient_counters$CumIparPot),
                            CumIparStr<-as.double(Rquotient_counters$CumIparStr),Srad<-as.double(DailyWeather$Srad),Dtt<-as.double(DailyThermalTime),
                            Pcarb<-as.double(energy_store$Pcarb),Vcarbo<-as.double(energy_store$Vcarbo),Setreserve<-as.double(energy_store$Setreserve),
                            Vreserve<-as.double(energy_store$Vreserve),IParIndex<-as.double(0),CumRadnDtt<-as.double(Rquotient_counters$CumRadndtt))
    Rquotient_counters$Rdtt2<-Rquotient_out[[1]]
    Rquotient_counters$CumRadn<-Rquotient_out[[3]]
    Rquotient_counters$CumStagDtt<-Rquotient_out[[4]]
    Rquotient_counters$CumIparPot<-Rquotient_out[[5]]
    Rquotient_counters$CumIparStr<-Rquotient_out[[6]]
    Rquotient_counters$CumRadndtt<-Rquotient_out[[14]]
    growth_stage_controls$Matdtt<-growth_stage_controls$Matdtt+Rquotient_counters$Rdtt2

    if(growth_stage_controls$Mature==1){
      iStage<-6
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY06 = DOY
      print("Harvested at target Brix")
      summary_output_variables$Harvest_at_target_Brix = 1
    } else if (growth_stage_controls$Matdtt>0 && DOY==150){
      iStage<-6
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY06 = DOY
      print("Harvested at maximum date")
      summary_output_variables$Harvest_at_target_Brix = 0
    }
  }else if(iStage==6){
    #Find Leaf fall
    growth_stage_controls$Cumdtt<-growth_stage_controls$Cumdtt+DailyThermalTime
    #call Rquotient
    growth_stage_controls$DaysSinceBudBurst<- growth_stage_controls$DaysSinceBudBurst+1

    if(growth_stage_controls$Cumdtt>=(Cultivar$P2BB$Value+Cultivar$P3FF$Value+growth_stage_controls$Setdd+Cultivar$P4HH$Value+Cultivar$P5LF$Value)){
      iStage<-7
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY07 = DOY
      print("leaf fall by thermal time")
      summary_output_variables$Leaf_fall_by_thermal_time = 1
    } else if(DOY>=150) {
      iStage<-7
      print(paste("Stage:",iStage,"    DOY:", DOY))
      summary_output_variables$DOY07 = DOY
      print("leaf fall by calendar")
      summary_output_variables$Leaf_fall_by_thermal_time = 0
    }
  }

  #End
  output<-list()
  output$growth_stage_controls<-growth_stage_controls
  output$iStage<-iStage
  output$FF_Index<-FF_Index
  output$Rquotient_counters<-Rquotient_counters
  output$berry_counts<-berry_counts

  output_and_summary_variables<-list(output, summary_output_variables)
  return(output_and_summary_variables)

}
