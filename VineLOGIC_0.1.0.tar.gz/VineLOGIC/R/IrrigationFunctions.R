#Created 14/04/2020

calc_irrigation_demand<-function(RuleBasedIrrigationData,
                                 SoilLayerDepth,NLAYR,Sw,
                                 SoilProfile,DailyWeather,Potet,
                                 CumNetET,iStage){

    #Do not water before bud burst
  if(iStage==1 || iStage>=7){
    return()
  }

  if(RuleBasedIrrigationData$IRON$Value[(iStage-1)]!='TRUE'){
    return()
  }

  #Calculate soil water deficit
  Wet1<-0
  TswTop<-0
  CumDepL<-0
  for(i in 1:NLAYR){
    if(CumDepL<RuleBasedIrrigationData$IRMANDEPTH$Value[(iStage-1)]){
      Xdepl<-CumDepL
      CumDepL<-CumDepL+SoilLayerDepth[i]
      if(CumDepL>RuleBasedIrrigationData$IRMANDEPTH$Value[(iStage-1)]){
        Xdep<-(RuleBasedIrrigationData$IRMANDEPTH$Value[(iStage-1)]-Xdepl)
      }else{
        Xdep<-SoilLayerDepth[i]
      }
      TswTop<-TswTop+(Sw[i]-SoilProfile$SoilLayerProperties$SLLL$Value[i])*Xdep
      Wet1<-Wet1+(SoilProfile$SoilLayerProperties$SDUL$Value[i]-SoilProfile$SoilLayerProperties$SLLL$Value[i])*Xdep
    }
  }
  ATheta<-TswTop/Wet1
  Swdef<-max(0,Wet1-TswTop)

  #Calculate ET deficit
  CumNetET<-CumNetET+Potet*10-DailyWeather$Rain

  output<-list()
  output$CumNetET<-CumNetET
  output$ATheta<-ATheta
  output$Swdef<-Swdef
  output$TswTop<-TswTop
  output$Wet1<-Wet1
  return(output)
}

apply_automatic_irrigation<-function(iStage,Date,Depir,RuleBasedIrrigationData,CumIRRStage,CumNetET,Swdef,LastIRDoy,JULAPL,AMIR,Nap,Totir,ATheta){

  if(iStage==1 || iStage>=7){
    return()
  }

  if(RuleBasedIrrigationData$IRON$Value[(iStage-1)]!='TRUE'){
    return()
  }

  if(RuleBasedIrrigationData$IRAUTODEFMETHOD$Value =='SWDRIVEN'){
    if(ATheta<(1-(RuleBasedIrrigationData$IRCRITSW$Value[(iStage-1)]*0.01))){
      Depir<-Swdef*10*RuleBasedIrrigationData$IRREFILLPER$Value[(iStage-1)]*0.01

      # impose daily max depir too
      if(Depir>RuleBasedIrrigationData$IRDAYSTAGECAP$Value[(iStage-1)]){
        Depir<-RuleBasedIrrigationData$IRDAYSTAGECAP$Value[(iStage-1)]
      }

    } else {
      Depir<-0
    }

    if(Date<(LastIRDoy+RuleBasedIrrigationData$IRRETNPERIOD$Value[(iStage-1)])){
      Depir<-0
    }

    CumIRRStage[(iStage-1)]<-CumIRRStage[(iStage-1)]+Depir
    if(CumIRRStage[(iStage-1)]>RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)]){
      Depir<-Depir-(CumIRRStage[(iStage-1)]-RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)])
      CumIRRStage[(iStage-1)]<-RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)]
    }
  } else {
    #Potet driven

    if(CumNetET>RuleBasedIrrigationData$IRCUMNETET$Value[(iStage-1)]){
      Depir<-RuleBasedIrrigationData$IRCUMNETET$Value[(iStage-1)]*RuleBasedIrrigationData$IRETIRRAMT$Value[(iStage-1)]*0.01

      # impose daily max depir too
      if(Depir>RuleBasedIrrigationData$IRDAYSTAGECAP$Value[(iStage-1)]){
        Depir<-RuleBasedIrrigationData$IRDAYSTAGECAP$Value[(iStage-1)]
      }

      CumIRRStage[(iStage-1)]<-CumIRRStage[(iStage-1)]+Depir
      if(CumIRRStage[(iStage-1)]>RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)]){
        Depir<-Depir-(CumIRRStage[(iStage-1)]-RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)])
        CumIRRStage[(iStage-1)]<-RuleBasedIrrigationData$IRSTAGECAP$Value[(iStage-1)]
      }
      if(Date<(LastIRDoy+RuleBasedIrrigationData$IRRETNPERIOD$Value[(iStage-1)])){
        Depir<-0
      }
    }
  }

  Irrec<-RuleBasedIrrigationData$IRWATEREC$Value[(iStage-1)]
  if(Depir!=0){
    LastIRDoy<-Date
    CumNetET<-0
    Nap<-Nap+1
    JULAPL[Nap]<-Date
    AMIR[Nap+1]<-Depir
    Totir<-Totir+Depir
  }
  output<-list()
  output$LastIRDoy<-LastIRDoy
  output$CumNetET<-CumNetET
  output$Nap<-Nap
  output$CumIRRStage<-CumIRRStage
  output$Depir<-Depir
  output$JULAPL<-JULAPL
  output$AMIR<-AMIR
  output$Totir<-Totir
  return(output)

}

read_daily_irrig<-function(Date=NULL,ObservedIrrigationTimeseries=NULL){
  index<-which(ObservedIrrigationTimeseries$Date==Date)
  output<-list()
  output$Depir<-ObservedIrrigationTimeseries$Amount.of.irrigaiton[index]
  return(output)
}
