#Created 1/04/2020

read_daily_weather<-function(Date=NULL,Weatherfile=NULL){
  index<-which(Weatherfile$Date==Date)
  output<-list()
  output$Tmax<-Weatherfile$TMAX[index]
  output$Tmin<-Weatherfile$TMIN[index]
  output$Tmean<-(output$Tmax+output$Tmin)/2
  output$Srad<-Weatherfile$SRAD[index]
  output$Rain<-Weatherfile$RAIN[index]
  output$Dew.Pt<-Weatherfile$Dew.Pt[index]
  return(output)

}


daily_thermal_time<-function(DailyWeather,TMFAC1,TBASE){

  DTT<-DailyWeather$Tmean-TBASE

  if(DailyWeather$Tmin<=TBASE || DailyWeather$Tmax>=34){
    if(DailyWeather$Tmax<TBASE){
      DTT<-0
    }
    if(DTT!=0){
      DTT<-0
      for(i in 1:8){
        TTMP<-DailyWeather$Tmin+TMFAC1[i]*(DailyWeather$Tmax-DailyWeather$Tmin)
        if(TTMP>TBASE && TTMP<=34){
          DTT<-DTT+(TTMP-TBASE)/8
        }
        if(TTMP>34 && TTMP<52){
          DTT<-DTT+(34-TBASE)*(1-(TTMP-34)/10)/8
        }
      }
    }
  }
  return(DTT)

}

vernilisation_factor<-function(DailyWeather,VF,CumVD,Cultivar){

  if(VF==1){      #if vernalization is complete (ie VF.eq.1) return
    output<-list()
    output$CumVD<-CumVD
    output$VF<-VF
    return(output)
  }
  if(DailyWeather$Tmin<=0){    #Minimum temperature less than zero - no vernalization so return
    output<-list()
    output$CumVD<-CumVD
    output$VF<-VF
    return(output)
  }
  VD<-0
  if(DailyWeather$Tmin<=15){    #If a high minimum occurs don't do any vernalization but check to see whether any devernalization occurred
    #Determine how much of a "vernalizing day" we receive today
    VD1<-1.4-0.0778*DailyWeather$Tmean
    VD2<-0.5+13.44/(DailyWeather$Tmax-DailyWeather$Tmin+3)**2*DailyWeather$Tmean
    VD<-min(1,VD1,VD2)
    VD<-max(0,VD)
    # Accumulate the number of vernalization days
    CumVD<-CumVD+VD
  }
  if(CumVD<10 && DailyWeather$Tmax>30){
    CumVD<-CumVD-0.5*(DailyWeather$Tmax-30)
  }
  CumVD<-max(CumVD,0)

  VF<-1-Cultivar$P1VV$Value*(50-CumVD)
  VF<-min(VF,1)
  VF<-max(VF,0)

  output<-list()
  output$CumVD<-CumVD
  output$VF<-VF
  return(output)
}

calc_evap<-function(DailyWeather,LAI,Salb){
  weighted_temp<-0.6*DailyWeather$Tmax+0.4*DailyWeather$Tmin

  if(LAI>0.01){
    Albedo<-0.23-(0.23-Salb)*exp(-0.75*LAI)
  } else {
    Albedo<-Salb
  }

  #Either read from file, or calculate
  #Below is calculate using Priestly Taylor

  LatHeatVap <- 2.50025 - 0.002365*DailyWeather$Tmean
  NetRad <- -1.5+0.61*DailyWeather$Srad
  Delta <- 0.1*exp(21.255-(5304/(DailyWeather$Tmean+273.1)))*(5304/(DailyWeather$Tmean+273.1)**2)
  Gamma <- 0.066
  Alpha <- 1.28
  if(DailyWeather$Tmax>20){Alpha<-Alpha+0.08*(DailyWeather$Tmax-20)}
  Pot_ET<-(Alpha*(Delta/(Delta+Gamma))*NetRad)/LatHeatVap
  Pot_ET<-Pot_ET*0.1 #convert back to cm for water balance

  Slang<-DailyWeather$Srad*23.923
  EEQ<-Slang*(0.000204-0.000183*Albedo)*(weighted_temp+29)
  Eo<-EEQ*1.1

  if(DailyWeather$Tmax>35){
    Eo<-EEQ*((DailyWeather$Tmax-35)*0.05+1.1)
  } else if (DailyWeather$Tmax<5){
    Eo<-EEQ*0.01*exp(0.18*(DailyWeather$Tmax+20))
  }
  Eo<-max(Eo,0.0001)*0.1

  if(LAI>1){
    Eos<-Pot_ET/1.1*exp(-0.4*LAI)
  } else {
    Eos<-Pot_ET*(1-0.43*LAI)
  }

  #Partition PotET into vine and soil
  RemPot_ET<-Pot_ET-Eos
  if(LAI==0){
    VineEop<-0
  } else {
    VineEop<-RemPot_ET*(1-exp(-2.5*LAI))
  }
  output<-list()
  output$Eos<-Eos
  output$VineEop<-VineEop
  output$Pot_ET<-Pot_ET
  return(output)

}
