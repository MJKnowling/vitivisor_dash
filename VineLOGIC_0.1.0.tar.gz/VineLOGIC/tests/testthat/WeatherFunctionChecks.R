# context("WeatherFunctionChecks")
# library(VineLOGIC)
#
#
# DailyWeather_test1<-list()
# DailyWeather_test1$Tmin<-16
# DailyWeather_test1$Tmax<-37
# DailyWeather_test1$Tmean<-26.5
#
# TMFAC1_test1<-c(0.9800, 0.9202, 0.7834, 0.6014, 0.4060, 0.2290, 0.1022, 0.0574)
#
# TBASE_test1<-7.5
#
# test_that("Output replicates vines",{
#   expect_equal(daily.thermal.time(DailyWeather = DailyWeather_test1,TMFAC1 = TMFAC1_test1,TBASE = TBASE_test1), 17.42766,tolerance=1e-5)
# })
#
# Cultivar_test1<-list()
# Cultivar_test1$P1VV$Value<-5
#
# VF_test1<-0
# CumVD_test1<-0
#
# test_that("Output replicates vines",{
#   expect_equal(vernilisation.factor(DailyWeather = DailyWeather_test1,VF = VF_test1, CumVD = CumVD_test1), 17.42766,tolerance=1e-5)
# })
